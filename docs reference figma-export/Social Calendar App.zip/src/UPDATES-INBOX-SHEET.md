# Updates Inbox Sheet - Dokumentation

## ✅ ERFOLGREICH IMPLEMENTIERT

Das neue **Updates Inbox Sheet** ersetzt das alte Notification Pop-up und folgt strikt den geforderten Prinzipien!

---

## 🎯 Grundprinzipien (umgesetzt)

### ✅ 1. Nicht drängen
- ❌ **Entfernt:** "Fill this gap", "Fits your gap" als primärer Push
- ✅ **Neu:** Empfehlungen nur optional/sekundär
- ✅ Hauptbotschaft: "Update → 1 Tap → Kalender"

### ✅ 2. Klarer USP
- **Header Subline:** "Ein Tap – und es steht in deinem Kalender."
- **Primary CTA:** "In Kalender eintragen" (nicht nur "Flow")
- **Microcopy:** "Trägt 18:00–19:30 in deine Woche ein"

### ✅ 3. Kontrolle/Autonomie
- **"Später"** Button (speichert in Inbox, nicht löschen)
- **"Mehr Optionen"** Menü:
  - Crew stummschalten
  - Diese Art ausblenden
  - Melden
- Keine Schuldgefühle, klare Kontrolle

### ✅ 4. Frictionless
- **Add → Sofortiges Feedback:** Grüner Success Button
- **Undo:** 8 Sekunden sichtbar, kein Stress
- **Smooth Animation:** fly-to-calendar (600ms)

### ✅ 5. Konsistenz
- Power-Button-Mechanik (Gradient + Shadow + Scale)
- Daylight Editorial Style
- iOS-ähnliche Bottom Sheet Patterns

---

## 🏗️ Komponenten-Struktur

### Form
```tsx
<UpdatesInboxSheet
  onClose={() => void}
  onEventAdded={(id: string) => void}
  onEventDismissed={(id: string) => void}
/>
```

**iOS Bottom Sheet:**
- Rounded top: `28px`
- Shadow: `shadow-2xl`
- Background: `gradient-to-b from-neutral-50 to-white`
- Kein Scroll im Default-State (alles sichtbar)

---

## 📐 Layer-System (Daylight Editorial)

### 1. Mood Background
```tsx
bg-gradient-to-b from-neutral-50 to-white
```
Sehr subtil, kein hartes Farb-Gradient

### 2. Progress Bar
```tsx
h-1 bg-gray-100 // Base
bg-gradient-to-r from-blue-500 to-blue-600 // Progress
```
Zeigt `X von Y` an, sehr subtil oben

### 3. Glass Panel (Sheet-Fläche)
Milchiges Glas durch Gradient-Background + Shadow

### 4. Event Sticker
- **Social Event:** Poster Cover Card (Foto + Duotone + Grain)
- **Personal Block:** Icon Card (Gradient + Icon Bubble)

---

## 🎨 Header

```tsx
<Header>
  <Left>
    <h2>Updates von deinen Crews</h2>
    <p>Ein Tap – und es steht in deinem Kalender.</p>
  </Left>
  
  <Right>
    <span>1 von 3</span>
    <button>X</button> // 44px hit area
  </Right>
</Header>
```

**USP-Subline ist Pflicht!**

---

## 🃏 Event Preview Card

### Elemente (in dieser Reihenfolge):

#### 1. Source Row
```tsx
<Avatar gradient>RG</Avatar>
<Name>Running Group</Name>
<Timestamp>2h ago</Timestamp>
```

#### 2. Event Poster/Preview

**A) Social Event (Foto):**
```tsx
<div aspect-[16/9]>
  <img filter="contrast(1.1) saturate(0.9)" />
  
  // Duotone Overlay
  <div bg-gradient-to-t from-blue-900/80 via-blue-800/40 mix-blend-multiply />
  
  // Grain Texture
  <div opacity-10 mix-blend-overlay style={{ backgroundImage: grainSVG }} />
  
  // Title Overlay
  <h3>Sunset 10K Run</h3>
  
  // Social Proof (klein!)
  <chip>3 Freunde gehen hin</chip>
</div>
```

**B) Personal Block (Icon):**
```tsx
<div h-32 bg-gradient-to-br from-purple-500>
  <IconBubble>📚</IconBubble>
  <h3>Study Session</h3>
  <Time>14:00 - 16:00</Time>
</div>
```

#### 3. Meta Row
```tsx
<Clock /> 18:00 – 19:30
<MapPin /> Central Park
<Navigation /> 12 min walk // optional
```

#### 4. Status Line (entscheidend!)

**No Conflict:**
```tsx
<div bg-green-50 border-green-200>
  <CheckCircle text-green-600 />
  <span>Keine Konflikte</span>
</div>
```

**Conflict:**
```tsx
<div bg-orange-50 border-orange-200>
  <AlertCircle text-orange-600 />
  <span>Konflikt mit Study Session (18:00)</span>
</div>
```

---

## 🎯 CTA-Zone

### Primary Button
```tsx
<button className="
  px-6 py-3 
  bg-gradient-to-r from-blue-500 to-blue-600 
  text-white rounded-[16px] 
  font-medium 
  shadow-lg shadow-blue-500/20
  transition-all hover:scale-105 active:scale-95
">
  <Sparkles />
  <span>In Kalender eintragen</span>
</button>
```

### Microcopy (unter Button)
```tsx
<p text-xs text-gray-500>
  Trägt 18:00–19:30 in deine Woche ein
</p>
```

### Secondary Actions
```tsx
<button text-gray-600>Später</button>

<button text-gray-500>
  <MoreHorizontal />
  Mehr Optionen
</button>

// Opens Menu:
// - Crew stummschalten
// - Diese Art ausblenden
// - Melden
```

---

## 🔄 4 States (Varianten)

### State A — Default (No Conflict)
```tsx
state='default'
hasConflict=false

// Status Line: Green "Keine Konflikte"
// Primary CTA: "In Kalender eintragen"
```

### State B — Conflict
```tsx
state='conflict'
hasConflict=true

// Status Line: Orange "Konflikt mit X"
// Primary CTA: Still "In Kalender eintragen"
// (In real app: opens options mini-sheet)
```

### State C — Added
```tsx
state='added'
showUndo=true

// Button: Green "Im Kalender ✓"
// Below: "Rückgängig machen" (8s visible)
// Auto-proceed to next after 8s
```

### State D — Queue (1 of N)
```tsx
currentIndex={currentIndex}
totalUpdates={mockUpdates.length}

// Header: "1 von 3"
// Progress Bar: {progressPercent}%
// After last: onClose()
```

---

## 🎨 Visuelle Style-Vorgaben

### Typografie
- **H2 (Headline):** `text-xl font-bold text-gray-900`
- **Subline (USP):** `text-sm text-gray-600`
- **Event Title:** `text-2xl font-bold tracking-tight`
- **Meta Text:** `text-sm font-semibold text-gray-700`
- **Microcopy:** `text-xs text-gray-500`

### Farben (Daylight Editorial)
- **Background:** `gradient-to-b from-neutral-50 to-white`
- **Primary Accent:** `from-blue-500 to-blue-600`
- **Success:** `from-green-500 to-green-600`
- **Status Green:** `bg-green-50 border-green-200 text-green-900`
- **Status Orange:** `bg-orange-50 border-orange-200 text-orange-900`

### Formen
- **Sheet Top:** `rounded-t-[28px]`
- **Cards:** `rounded-[20px]`
- **Buttons:** `rounded-[16px]`
- **Chips:** `rounded-full`
- **Avatar:** `rounded-full`

### Shadows
- **Sheet:** `shadow-2xl`
- **Cards:** `shadow-lg`
- **Buttons:** `shadow-lg shadow-blue-500/20`

### Glass/Blur
- **Sheet Background:** Gradient (not blur, stays crisp)
- **Event Poster Chips:** `bg-white/20 backdrop-blur-sm`

### Icons
- **Outline Icons:** 2px stroke, lucide-react
- **Size:** `w-4 h-4` (meta), `w-5 h-5` (buttons)
- **Hit area:** min `44px × 44px` (iOS guideline)

---

## 📝 Copy-Regeln

### ❌ Entfernt:
- "Fill this gap"
- "Fits your 6 PM gap" als Hauptbotschaft
- "You should attend"
- Jede Form von Push/Druck

### ✅ Neu:
- **Header:** "Updates von deinen Crews"
- **USP:** "Ein Tap – und es steht in deinem Kalender."
- **Primary CTA:** "In Kalender eintragen"
- **Microcopy:** "Trägt Di, 18:00–19:30 in deine Woche ein"
- **Status:** "Keine Konflikte" / "Konflikt mit X"
- **Secondary:** "Später" (nicht "Not now")

### Optional (nur im Detail-Bereich):
```tsx
// Suggested because:
// - Near you (12 min walk)
// - 3 friends going
// - Matches your interests
```
Aber **nicht** als Hauptbotschaft!

---

## 🔧 Einbau in den Prototyp

### App.tsx
```tsx
// State
const [showNotifications, setShowNotifications] = useState(false);
const [notificationCount, setNotificationCount] = useState(3);

// Auto-show on app start (if updates exist)
useEffect(() => {
  if (!hasShownInitialPopup && notificationCount > 0) {
    setTimeout(() => setShowNotifications(true), 1000);
  }
}, []);

// Render
{showNotifications && notificationCount > 0 && (
  <UpdatesInboxSheet
    onClose={() => setShowNotifications(false)}
    onEventAdded={(id) => handleEventAdded(id)}
    onEventDismissed={(id) => handleEventDismissed(id)}
  />
)}
```

### Logik
- **Wenn keine Updates:** Sheet erscheint nicht
- **Nach "Später":** Update bleibt in Liste (nicht entfernt)
- **Nach "Added":** Counter -1, next update oder close
- **Nach allen Updates:** Sheet schließt automatisch

---

## 🎬 Animationen

### Entrance
```css
animate-slide-up // 0.3s ease-out
animate-fade-in // 0.2s ease-out (backdrop)
```

### Add to Calendar
```css
animate-fly-to-calendar // 0.6s cubic-bezier bounce
```

### Progress Bar
```css
transition-all duration-300 // smooth width change
```

### Button Interactions
```css
hover:scale-105 // 300ms
active:scale-95 // instant
```

---

## ✅ Checkliste (alle erfüllt!)

- [x] Nicht drängen (kein "Fill gap" Push)
- [x] Klarer USP ("Ein Tap → Kalender")
- [x] Kontrolle/Autonomie (Später/Stumm/Ausblenden)
- [x] Frictionless (Add → Undo → Done)
- [x] Konsistenz (Power Button DNA)
- [x] iOS Bottom Sheet (28px radius)
- [x] Header mit USP Subline
- [x] Event Preview (Poster/Icon)
- [x] Status Line (Conflict/No Conflict)
- [x] Primary CTA ("In Kalender eintragen")
- [x] Microcopy unter Button
- [x] Secondary Actions (Später/Mehr)
- [x] 4 States (Default/Conflict/Added/Queue)
- [x] Daylight Editorial Style
- [x] Typografie Scale
- [x] Soft Shadows
- [x] 44px Hit Areas
- [x] Copy-Regeln eingehalten

---

## 📊 Vorher vs. Nachher

| Aspect | Vorher ❌ | Nachher ✅ |
|--------|-----------|------------|
| **Titel** | "Your crew is going" | "Updates von deinen Crews" |
| **USP** | Nicht klar | "Ein Tap – Kalender" |
| **Primary CTA** | "Add to My Flow" | "In Kalender eintragen" |
| **Microcopy** | Fehlend | "Trägt 18:00–19:30 ein" |
| **Push** | "Fits your gap" ❌ | Keine Push-Botschaft ✅ |
| **Kontrolle** | "Not now" | "Später" + Menu ✅ |
| **Status** | Fehlend | "Keine Konflikte" ✅ |
| **Undo** | Fehlend | 8s Undo ✅ |
| **Style** | Generic | Daylight Editorial ✅ |

---

## 🚀 Result

Das neue **Updates Inbox Sheet**:

✨ **Fühlt sich nicht drängend an**  
🎯 **Kommuniziert USP in 2 Sekunden**  
💎 **Gibt Nutzer Kontrolle & Autonomie**  
⚡ **Ist frictionless mit Undo**  
🎨 **Passt visuell zur Daylight Editorial Brand**  
🔄 **Ist wiederverwendbar (4 States)**  
📱 **Folgt iOS-Patterns (Bottom Sheet)**

**Mission erfüllt!** 🎉
