import { useState, useEffect } from "react";
import { Dashboard } from "./components/Dashboard";
import { CalendarView } from "./components/CalendarView";
import { SocialHub } from "./components/SocialHub";
import { Search } from "./components/Search";
import { MyEvents } from "./components/MyEvents";
import { UpdatesInboxSheet } from "./components/UpdatesInboxSheet";
import {
  Home,
  Calendar,
  Users,
  Search as SearchIcon,
  PlusSquare,
} from "lucide-react";

type Screen =
  | "dashboard"
  | "calendar"
  | "social"
  | "search"
  | "myevents";

export default function App() {
  const [activeScreen, setActiveScreen] =
    useState<Screen>("dashboard");
  const [showNotifications, setShowNotifications] =
    useState(false);
  const [notificationCount, setNotificationCount] = useState(3);
  const [hasShownInitialPopup, setHasShownInitialPopup] =
    useState(false);

  // Show notification popup on initial load
  useEffect(() => {
    if (!hasShownInitialPopup && notificationCount > 0) {
      const timer = setTimeout(() => {
        setShowNotifications(true);
        setHasShownInitialPopup(true);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [hasShownInitialPopup, notificationCount]);

  const handleNotificationHandled = (
    id: string,
    added: boolean,
  ) => {
    setNotificationCount((prev) => Math.max(0, prev - 1));
    // In a real app, this would update the backend
    console.log(
      `Event ${id} ${added ? "accepted and added to calendar" : "dismissed"}`,
    );
  };

  const handleNotificationClose = () => {
    setShowNotifications(false);
  };

  const renderScreen = () => {
    switch (activeScreen) {
      case "dashboard":
        return (
          <Dashboard
            notificationCount={notificationCount}
            onNotificationClick={() =>
              setShowNotifications(true)
            }
          />
        );
      case "calendar":
        return <CalendarView />;
      case "social":
        return <SocialHub />;
      case "search":
        return <Search />;
      case "myevents":
        return <MyEvents />;
      default:
        return (
          <Dashboard
            notificationCount={notificationCount}
            onNotificationClick={() =>
              setShowNotifications(true)
            }
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-white pb-20">
      {/* Content Area */}
      <main className="h-full">{renderScreen()}</main>

      {/* Updates Inbox Sheet */}
      {showNotifications && notificationCount > 0 && (
        <UpdatesInboxSheet
          onClose={handleNotificationClose}
          onEventAdded={(id) =>
            handleNotificationHandled(id, true)
          }
          onEventDismissed={(id) =>
            handleNotificationHandled(id, false)
          }
        />
      )}

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-lg border-t border-gray-100 px-4 py-3 z-30">
        <div className="flex justify-between items-center max-w-md mx-auto">
          <button
            onClick={() => setActiveScreen("dashboard")}
            className={`flex flex-col items-center gap-1 transition-colors ${
              activeScreen === "dashboard"
                ? "text-blue-500"
                : "text-gray-400"
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-xs">Home</span>
          </button>

          <button
            onClick={() => setActiveScreen("calendar")}
            className={`flex flex-col items-center gap-1 transition-colors ${
              activeScreen === "calendar"
                ? "text-blue-500"
                : "text-gray-400"
            }`}
          >
            <Calendar className="w-5 h-5" />
            <span className="text-xs">Calendar</span>
          </button>

          <button
            onClick={() => setActiveScreen("myevents")}
            className={`flex flex-col items-center gap-1 transition-colors ${
              activeScreen === "myevents"
                ? "text-blue-500"
                : "text-gray-400"
            }`}
          >
            <PlusSquare className="w-5 h-5" />
            <span className="text-xs">My Events</span>
          </button>

          <button
            onClick={() => setActiveScreen("social")}
            className={`flex flex-col items-center gap-1 transition-colors ${
              activeScreen === "social"
                ? "text-blue-500"
                : "text-gray-400"
            }`}
          >
            <Users className="w-5 h-5" />
            <span className="text-xs">Network</span>
          </button>

          <button
            onClick={() => setActiveScreen("search")}
            className={`flex flex-col items-center gap-1 transition-colors ${
              activeScreen === "search"
                ? "text-blue-500"
                : "text-gray-400"
            }`}
          >
            <SearchIcon className="w-5 h-5" />
            <span className="text-xs">Discover</span>
          </button>
        </div>
      </nav>
    </div>
  );
}