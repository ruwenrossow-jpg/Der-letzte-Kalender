# For You Feed - Hooked Model & Marketing Psychologie

## 🎯 **ANALYSE AUS MARKETING-PSYCHOLOGIE-SICHT**

Der neue **"For You" Feed** folgt dem **Hooked Model** (Nir Eyal) und nutzt bewährte Prinzipien erfolgreicher Apps wie Instagram, TikTok, eBay, Amazon und Strava.

---

## 📊 **HOOKED MODEL - 4 PHASEN**

### **1️⃣ TRIGGER (Interner + Externer)**

#### **Problem/Pain:**
> "Mein Wochenende ist noch unklar. Ich möchte rauskommen und was erleben."

#### **Lösung im Design:**

**A) Flow Card (Visueller Trigger):**
```tsx
<FlowCard>
  // Zeigt visuelle Timeline mit "leeren Lücken"
  [Event] → [Event] → [---] → [?]
  
  // Trigger-Text (nicht pushy!)
  "3 neue Events passen in deine Woche"
  
  // Neugier-Element
  <BlueDot animate-pulse /> {newOpportunities} neue Events
</FlowCard>
```

**Psychologie:**
- ✅ **Zeigarnik-Effekt:** Unvollständige Timeline = Drang zu vervollständigen
- ✅ **Visuelle Lücken:** Gehirn will Muster vervollständigen
- ✅ **Positive Framing:** "Opportunities" statt "Fill your gap"
- ✅ **Subtil:** Keine aggressiven CTAs

**B) Badge Count:**
```tsx
<Bell>
  <Badge>3</Badge> // External Trigger
</Bell>
```

---

### **2️⃣ ACTION (Einfachheit + Motivation)**

#### **Fogg Behavior Model:**
> Action = Motivation × Ability × Trigger

#### **Lösung im Design:**

**Motivation erhöhen:**
- 📸 **Visual-First:** Große Poster Images (4:5 ratio)
- 👥 **Social Proof:** "3 Freunde gehen hin"
- 🔥 **FOMO Badges:** "Trending" / "New" / "Near you"
- ⭐ **Variable Rewards:** Nicht jedes Event hat gleiche Badges

**Ability maximieren:**
- 📱 **Infinite Scroll:** Kein "Load More" Button
- ⚡ **Schnelles Scrollen:** Weniger Text, mehr Visual
- 🎯 **Quick Filters:** "Sport" / "Nightlife" / "Uni"
- 💚 **Heart/Save:** Keine Friction, instant Feedback

**Design-Entscheidungen:**

```tsx
// Instagram-Style Card
<EventCard aspect-ratio="4:5"> // Nicht 16:9!
  
  // Minimale Info auf Card
  <Title>Sunset 10K Run</Title>
  <Time>18:00</Time>
  <Location>Central Park</Location>
  
  // Tap to see details
  onClick={openDetailModal}
  
</EventCard>
```

**Warum 4:5 statt 16:9?**
- ✅ Größere Bilder = emotionalere Wirkung
- ✅ Weniger Cards pro Screen = Fokus
- ✅ Mehr Scroll-Bewegung = Engagement
- ✅ Instagram-Gewöhnung der Nutzer

---

### **3️⃣ VARIABLE REWARD (Kern des Hooked Models!)**

#### **3 Arten von Belohnungen:**

**A) Rewards of the Tribe (Soziale Belohnungen):**
```tsx
// Variable Social Proof
{friendsGoing >= 5 && (
  <Badge bg-green-500>
    <Users /> {friendsGoing} friends going
  </Badge>
)}

// Manchmal Freunde, manchmal nur Attendees
{attendees && !friendsGoing && (
  <Chip>{attendees} Teilnehmer</Chip>
)}
```

**Psychologie:**
- ✅ **Nicht vorhersehbar:** Mal Freunde, mal keine
- ✅ **FOMO:** "12 Freunde gehen hin" = starker Trigger
- ✅ **Social Validation:** Crowd = sicher, beliebt

**B) Rewards of the Hunt (Entdeckung):**
```tsx
// FOMO Badges (variabel!)
const badges = [
  { icon: Flame, text: 'Trending', color: 'orange' },
  { icon: Zap, text: 'New', color: 'blue' },
  { icon: Star, text: 'Near you', color: 'purple' },
];

// Nicht jedes Event hat Badge
// = Variable Reward
```

**Psychologie:**
- ✅ **Überraschung:** Welches coole Event als nächstes?
- ✅ **Discovery:** Wie eBay/Amazon Browsing
- ✅ **Neuheit:** "New" Badge = Exklusivität
- ✅ **Scarcity:** "Trending" = beliebt, könnte voll werden

**C) Rewards of the Self (Selbstverwirklichung):**
```tsx
// "Ich kuratiere mein perfektes Wochenende"
<SaveButton>
  <Heart fill={isSaved} />
</SaveButton>

// Flow Card zeigt Fortschritt
<Timeline>
  [Event] → [Event] → [Saved Event] → [?]
</Timeline>
```

**Psychologie:**
- ✅ **Autonomie:** Nutzer kontrolliert sein Wochenende
- ✅ **Kompetenz:** "Ich finde die besten Events"
- ✅ **Identität:** "Das passt zu mir"

---

### **4️⃣ INVESTMENT (Commitment steigern)**

#### **Kleine Investments = größere Retention:**

**A) Saving Events (niedrige Hürde):**
```tsx
<HeartButton onClick={saveEvent}>
  // Instant Feedback, keine Bestätigung
  // = Low friction
</HeartButton>
```

**B) Adding to Calendar:**
```tsx
<PowerButton>
  In Kalender eintragen
</PowerButton>

// Nach dem Tap:
// - Event bleibt im Feed (wie Instagram!)
// - Nutzer kann weiter scrollen
// - Sammelt mehr Events
```

**C) Filtering (Präferenzen lernen):**
```tsx
<QuickFilters>
  <Filter active={activeFilter === 'sports'}>
    ⚽ Sport
  </Filter>
</QuickFilters>

// Jeder Tap = Investment
// App lernt Präferenzen
// Feed wird besser
```

**Psychologie:**
- ✅ **Data als Investment:** Je mehr Nutzer filtert/saved, desto besser wird Feed
- ✅ **Sunk Cost:** "Ich habe schon 5 Events gesaved, jetzt muss ich sie auch nutzen"
- ✅ **Habit Formation:** Jeden Tag 5 Minuten scrollen = Gewohnheit

---

## 🧠 **PSYCHOLOGIE-PRINZIPIEN VON ERFOLGREICHEN APPS**

### **Instagram/TikTok:**

| Prinzip | Implementierung | Warum |
|---------|----------------|-------|
| **Infinite Scroll** | `IntersectionObserver` auto-load | Endlose Entdeckung |
| **Variable Rewards** | FOMO Badges variieren | Nie wissen, was kommt |
| **Visual-First** | 4:5 Poster Images | Emotionale Wirkung |
| **Double-Tap Like** | Heart Button (instant) | Frictionless |
| **Story-Style Filters** | Horizontal Chips | Schnelles Switching |

**Code-Beispiel:**
```tsx
// Infinite Scroll wie Instagram
useEffect(() => {
  const observer = new IntersectionObserver(
    (entries) => {
      if (entries[0].isIntersecting) {
        loadMoreEvents(); // Seamless!
      }
    },
    { threshold: 0.5 }
  );
  
  observer.observe(loadMoreTriggerRef.current);
}, []);
```

---

### **eBay/Amazon (Discovery Browsing):**

| Prinzip | Implementierung | Warum |
|---------|----------------|-------|
| **Stöbern macht Spaß** | Lange Feed-Liste | Entdeckung ohne Ziel |
| **Scarcity** | "6 spots left" Badges | Dringlichkeit |
| **Reviews/Ratings** | Social Proof (Freunde) | Trust |
| **"Others viewed"** | Algorithmus: Ähnliche Events | Personalisierung |

**Psychologie:**
- ✅ **Hedonisches Shoppen:** Nicht zielgerichtet, nur Spaß
- ✅ **Opportunitätskauf:** "Wow, das passt ja perfekt!"
- ✅ **FOMO:** "Nur noch wenige Plätze"

---

### **Strava (Social Competition):**

| Prinzip | Implementierung | Warum |
|---------|----------------|-------|
| **Leaderboards** | "12 Freunde gehen hin" | Competition |
| **Achievements** | "Trending" Badge | Gamification |
| **Segments** | Category Filters | Spezialisierung |
| **Kudos** | Heart/Save Button | Social Validation |

**Psychologie:**
- ✅ **Social Comparison:** "Meine Freunde sind aktiver als ich"
- ✅ **Badges:** Extrinsische Motivation
- ✅ **Streaks:** Gewohnheitsbildung

---

## 🎨 **DESIGN-ENTSCHEIDUNGEN (KISS-Prinzip)**

### **1. Flow Card (Trigger)**

**Vorher:**
```tsx
❌ "Fits your 6 PM gap" // Pushy!
❌ "Fill this gap" // Druck!
```

**Nachher:**
```tsx
✅ Visuelle Timeline mit "Lücken"
✅ "3 neue Events passen in deine Woche"
✅ Blaue Pulse-Dot (subtil)
✅ "Opportunities waiting" Mindset
```

**Psychologie:**
- **Loss Aversion vermeiden:** Keine "Du verpasst was!" Botschaft
- **Positive Framing:** "Opportunities" statt "Gaps"
- **Visuell > Text:** Timeline zeigt, was Sache ist

---

### **2. For You Header**

**Design:**
```tsx
<Header>
  <Title>For You</Title>
  <Subtitle>Handpicked für diese Woche</Subtitle>
  <TrendingIcon />
</Header>
```

**Psychologie:**
- ✅ **Personalisierung:** "For You" = speziell für mich
- ✅ **Curation:** "Handpicked" = Qualität, nicht Spam
- ✅ **Zeitrahmen:** "Diese Woche" = konkret, nicht ewig

---

### **3. Quick Filters (Story-Style)**

**Design:**
```tsx
<Filters horizontal scrollable>
  <Chip active>✨ Alle</Chip>
  <Chip>⚽ Sport</Chip>
  <Chip>🎉 Nightlife</Chip>
  <Chip>📚 Uni</Chip>
</Filters>
```

**Psychologie:**
- ✅ **Emojis:** Emotional, playful
- ✅ **Horizontal Scroll:** Wie Instagram Stories (familiar)
- ✅ **Active State:** Klares Feedback
- ✅ **Investment:** Jeder Tap = Präferenz gespeichert

---

### **4. Event Cards (4:5 Ratio)**

**Warum nicht 16:9 (Standard)?**

| Aspect | 16:9 (Vorher) | 4:5 (Nachher) |
|--------|---------------|---------------|
| **Screen Coverage** | 40% | 70% |
| **Emotional Impact** | Mittel | Hoch |
| **Scroll Frequency** | Weniger | Mehr |
| **Focus** | Mehrere Cards | Eine Card |
| **Platform Gewöhnung** | YouTube | Instagram ✅ |

**Psychologie:**
- ✅ **Größer = wichtiger:** Gehirn nimmt große Bilder ernster
- ✅ **Immersion:** Füllt fast ganzen Screen = fokussiert
- ✅ **Scroll-Engagement:** Mehr Bewegung = mehr Dopamin

---

### **5. FOMO Badges (Variable Rewards!)**

**Nicht jedes Event hat Badge = Variable Reward!**

```tsx
// Algorithmus
const random = (event.id + index) % 5;

if (friendsGoing >= 5) return 'Friends Going';
if (random === 0) return 'Trending';
if (random === 1) return 'New';
if (random === 2) return 'Near you';
return null; // Manchmal kein Badge!
```

**Psychologie:**
- ✅ **Überraschung:** Nie wissen, welches Event "special" ist
- ✅ **Scarcity:** Nicht alle Events sind "Trending"
- ✅ **FOMO:** "Trending" = könnte ausverkauft sein

**Badge-Hierarchie:**
1. 🟢 **Green (Friends):** Stärkster Trigger (Social Proof)
2. 🟠 **Orange (Trending):** FOMO (Scarcity)
3. 🔵 **Blue (New):** Neuheit (Exklusivität)
4. 🟣 **Purple (Near you):** Convenience (Effort)

---

### **6. Save/Heart Button**

**Design:**
```tsx
<HeartButton
  position="top-right"
  onClick={instantSave}
  feedback="scale-animation"
>
  <Heart fill={isSaved ? 'red' : 'none'} />
</HeartButton>
```

**Psychologie:**
- ✅ **Instagram-Pattern:** Nutzer kennt es bereits
- ✅ **Instant Feedback:** Keine Bestätigung nötig
- ✅ **Visual Reward:** Fill-Animation = Dopamin
- ✅ **Low Commitment:** Später entfernen möglich

---

### **7. Power Button (Investment)**

**Design:**
```tsx
<PowerButton
  position="bottom-strip"
  gradient="blue-500 to blue-600"
  shadow="shadow-lg shadow-blue-500/20"
>
  <Sparkles />
  In Kalender eintragen
</PowerButton>
```

**Psychologie:**
- ✅ **Prominent:** Nimmt volle Breite ein
- ✅ **Gradient:** Premium-Feel
- ✅ **Icon:** Sparkles = Reward
- ✅ **Clear CTA:** Kein Zweifel, was passiert

**Wichtig:** Event bleibt im Feed (wie Instagram!)
- Nutzer kann weiter scrollen
- Sammelt mehrere Events
- Höheres Engagement

---

### **8. Infinite Scroll**

**Warum kein "Load More" Button?**

| Load More Button | Infinite Scroll |
|------------------|-----------------|
| Friction (Tap erforderlich) | Frictionless |
| Unterbricht Flow | Seamless |
| Bewusste Entscheidung | Unbewusst |
| Weniger Engagement | Höheres Engagement |

**Psychologie:**
- ✅ **Zeigarnik-Effekt:** Unvollständige Liste = weiter scrollen
- ✅ **Variable Rewards:** Nie wissen, was als nächstes kommt
- ✅ **Habit Loop:** Scroll → Discover → Dopamine → Scroll

---

## 📈 **VERGLEICH: VORHER vs. NACHHER**

### **Trigger Phase:**

| Vorher | Nachher |
|--------|---------|
| ❌ "Fits your gap" (pushy) | ✅ Visuelle Timeline |
| ❌ Text-lastig | ✅ Visuell (Lücken) |
| ❌ Keine Opportunity Count | ✅ "3 neue Events" Badge |

---

### **Action Phase:**

| Vorher | Nachher |
|--------|---------|
| ❌ 3-4 Events (statisch) | ✅ Infinite Scroll |
| ❌ 16:9 Cards (klein) | ✅ 4:5 Cards (groß) |
| ❌ Keine Filter | ✅ Quick Filters |
| ❌ Viel Text | ✅ Visual-first |

---

### **Variable Reward Phase:**

| Vorher | Nachher |
|--------|---------|
| ❌ Gleiche Info auf allen Cards | ✅ Variable FOMO Badges |
| ❌ Predictable | ✅ Überraschung |
| ❌ Keine Social Proof Variation | ✅ Mal Freunde, mal nicht |
| ❌ Standard Layout | ✅ Mix aus Typen |

---

### **Investment Phase:**

| Vorher | Nachher |
|--------|---------|
| ❌ Nur "Add to Flow" | ✅ Save/Heart + Add |
| ❌ Event verschwindet | ✅ Event bleibt (Instagram) |
| ❌ Keine Filters | ✅ Filter = Investment |
| ❌ Keine Personalisierung | ✅ Algorithmus lernt |

---

## 🎯 **USP KOMMUNIKATION (2 SEKUNDEN)**

### **Flow Card:**
```
[Visuelle Timeline] → [3 neue Events] → [Blaue Pulse-Dot]

Nutzer versteht in 2 Sekunden:
1. "Meine Woche hat Lücken"
2. "Es gibt passende Events"
3. "Ich kann sie einfach eintragen"
```

### **For You Header:**
```
"For You
Handpicked für diese Woche"

Nutzer versteht:
1. "Speziell für mich"
2. "Kuratiert, nicht Spam"
3. "Aktuell relevant"
```

---

## 🧪 **A/B TEST HYPOTHESEN**

### **Test 1: Card Size**
- **A:** 16:9 ratio (Standard)
- **B:** 4:5 ratio (Instagram)
- **Hypothese:** 4:5 = +30% Engagement

### **Test 2: FOMO Badges**
- **A:** Alle Events haben Badge
- **B:** Variable Badges (50%)
- **Hypothese:** Variable = +20% Scroll-Time

### **Test 3: Infinite Scroll**
- **A:** "Load More" Button
- **B:** Auto-Load
- **Hypothese:** Auto = +40% Events viewed

### **Test 4: Save Button**
- **A:** Kein Save, nur Add
- **B:** Heart/Save Button
- **Hypothese:** Save = +25% Retention

---

## ✅ **CHECKLISTE: HOOKED MODEL ERFÜLLT**

### **Trigger:**
- [x] Visueller Trigger (Flow Timeline)
- [x] Externer Trigger (Badge Count)
- [x] Interner Trigger ("Wochenende leer")
- [x] Positive Framing (Opportunities)

### **Action:**
- [x] Einfach (Infinite Scroll)
- [x] Motivierend (FOMO Badges)
- [x] Visual-First (4:5 Cards)
- [x] Quick Filters (Low Friction)

### **Variable Reward:**
- [x] Social Rewards (Freunde)
- [x] Hunt Rewards (Discovery)
- [x] Self Rewards (Curation)
- [x] Überraschung (Variable Badges)

### **Investment:**
- [x] Save/Heart (Low Commitment)
- [x] Add to Calendar (Higher Commitment)
- [x] Filtering (Präferenzen)
- [x] Scroll Data (Algorithmus)

---

## 🚀 **RESULT: ENGAGEMENT-LOOP**

```
1. TRIGGER
   "Mein Wochenende ist leer"
   → Flow Card zeigt Lücken
   → "3 neue Events passen"
   
2. ACTION
   → App öffnen
   → Feed scrollen
   → Quick Filter (Sport)
   
3. VARIABLE REWARD
   → "Trending" Badge!
   → "5 Freunde gehen hin"
   → Cooles Poster
   → Dopamin Release
   
4. INVESTMENT
   → Heart/Save Event
   → Weiter scrollen
   → Mehr Events entdecken
   → Algorithmus lernt
   
5. REPEAT
   → Nächstes Mal besserer Feed
   → Stärkerer Trigger
   → Habit gebildet
```

---

## 💡 **NÄCHSTE OPTIMIERUNGEN**

1. **Push Notifications:** "3 neue Events passen in deine Woche"
2. **Daily Digest:** "Trending this weekend"
3. **Friend Activity:** "Sarah hat 5 Events gesaved"
4. **Streaks:** "7 Tage in Folge etwas erlebt"
5. **Badges/Achievements:** "Nightlife Explorer"

**Das ist der Hooked-Model-optimierte For You Feed! 🎉**
