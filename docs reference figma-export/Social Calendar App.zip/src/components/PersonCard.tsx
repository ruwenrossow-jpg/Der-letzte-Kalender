import { UserPlus, Check } from 'lucide-react';
import { useState } from 'react';

export type PersonData = {
  id: string;
  name: string;
  avatar?: string;
  initials: string;
  descriptor: string; // "12 events/month", "active tonight"
  mutualFriends?: number;
  nextEvent?: string; // "Next: Tue 18:00"
  eventThumbnails?: string[]; // max 3 tiny thumbnails
  type: 'person' | 'crew' | 'professor' | 'place';
};

type PersonCardProps = {
  person: PersonData;
  onFollow: (personId: string) => void;
  onClick?: (person: PersonData) => void;
};

export function PersonCard({ person, onFollow, onClick }: PersonCardProps) {
  const [isFollowing, setIsFollowing] = useState(false);

  const handleFollow = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFollowing(!isFollowing);
    onFollow(person.id);
  };

  const getActionLabel = () => {
    if (isFollowing) return 'Following';
    switch (person.type) {
      case 'crew':
        return 'Join Crew';
      case 'professor':
        return 'Follow';
      case 'place':
        return 'Save Place';
      default:
        return 'Follow';
    }
  };

  return (
    <div
      onClick={() => onClick?.(person)}
      className="bg-white rounded-[20px] p-4 shadow-sm hover:shadow-md transition-all cursor-pointer"
    >
      <div className="flex items-start gap-3">
        {/* Avatar */}
        <div className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white flex-shrink-0">
          {person.avatar ? (
            <img src={person.avatar} alt={person.name} className="w-full h-full rounded-full object-cover" />
          ) : (
            <span className="text-lg">{person.initials}</span>
          )}
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <h4 className="text-gray-900 mb-1">{person.name}</h4>
          <p className="text-sm text-gray-500 mb-2">{person.descriptor}</p>

          {/* Mutual Friends */}
          {person.mutualFriends && person.mutualFriends > 0 && (
            <p className="text-xs text-gray-400 mb-2">{person.mutualFriends} mutual friends</p>
          )}

          {/* Event Previews */}
          {person.eventThumbnails && person.eventThumbnails.length > 0 && (
            <div className="flex gap-1 mb-2">
              {person.eventThumbnails.slice(0, 3).map((thumb, i) => (
                <div key={i} className="w-10 h-10 rounded-lg overflow-hidden">
                  <img src={thumb} alt="" className="w-full h-full object-cover" />
                </div>
              ))}
              {person.nextEvent && (
                <div className="ml-1 text-xs text-gray-500 flex items-center">
                  {person.nextEvent}
                </div>
              )}
            </div>
          )}

          {/* Action Button */}
          <button
            onClick={handleFollow}
            className={`px-4 py-2 rounded-full text-sm transition-all ${
              isFollowing
                ? 'bg-gray-100 text-gray-700'
                : 'bg-blue-50 text-blue-600 hover:bg-blue-100'
            }`}
          >
            {isFollowing ? (
              <>
                <Check className="w-4 h-4 inline mr-1" />
                {getActionLabel()}
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4 inline mr-1" />
                {getActionLabel()}
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

// Grid variant for "People near you"
export function PersonCardCompact({ person, onFollow }: { person: PersonData; onFollow: (id: string) => void }) {
  const [isFollowing, setIsFollowing] = useState(false);

  const handleFollow = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFollowing(!isFollowing);
    onFollow(person.id);
  };

  return (
    <div className="flex flex-col items-center">
      <div className="relative mb-2">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white">
          {person.avatar ? (
            <img src={person.avatar} alt={person.name} className="w-full h-full rounded-full object-cover" />
          ) : (
            <span>{person.initials}</span>
          )}
        </div>
        {person.mutualFriends && person.mutualFriends > 0 && (
          <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 rounded-full border-2 border-white flex items-center justify-center text-white text-xs">
            {person.mutualFriends}
          </div>
        )}
      </div>
      <p className="text-sm text-gray-900 text-center mb-1">{person.name}</p>
      <p className="text-xs text-gray-500 text-center mb-2">{person.descriptor}</p>
      <button
        onClick={handleFollow}
        className={`px-3 py-1 rounded-full text-xs transition-all ${
          isFollowing
            ? 'bg-gray-100 text-gray-700'
            : 'bg-blue-50 text-blue-600 hover:bg-blue-100'
        }`}
      >
        {isFollowing ? 'Following' : 'Follow'}
      </button>
    </div>
  );
}
