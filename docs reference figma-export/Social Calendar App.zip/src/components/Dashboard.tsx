import { Bell, Sparkles, ChevronRight, Heart, TrendingUp, Clock, MapPin, Users, Flame, Star, Zap } from 'lucide-react';
import { useEffect, useState, useRef, useCallback } from 'react';
import { EventCard, type EventCardData } from './EventCard';
import { EventDetailModal, type EventDetail } from './EventDetailModal';

type DashboardProps = {
  notificationCount: number;
  onNotificationClick: () => void;
};

type FeedFilter = 'all' | 'sports' | 'nightlife' | 'university' | 'personal';

// ===== EXTENDED FEED DATA (für Infinite Scroll Gefühl) =====
const createFeedEvents = (): EventCardData[] => [
  {
    id: 'feed-1',
    title: 'Sunset 10k Run',
    time: 'Today, 18:00',
    endTime: '19:30',
    location: 'Central Park',
    source: 'Running Group',
    imageUrl: 'https://images.unsplash.com/photo-1699959560616-aa17ace76879?w=800',
    friendsGoing: 3,
    distance: '12 min walk',
    category: 'sports',
  },
  {
    id: 'feed-2',
    title: 'Coffee & Code Meetup',
    time: 'Today, 14:00',
    endTime: '16:00',
    location: 'Campus Library',
    source: 'CS Department',
    imageUrl: 'https://images.unsplash.com/photo-1623121181613-eeced17aea39?w=800',
    attendees: 8,
    distance: '5 min walk',
    category: 'university',
  },
  {
    id: 'feed-3',
    title: 'Downtown Bar Crawl',
    time: 'Tonight, 20:00',
    endTime: '23:00',
    location: 'City Center',
    source: 'Party Crew',
    imageUrl: 'https://images.unsplash.com/photo-1759870075384-4e82adc2f679?w=800',
    friendsGoing: 5,
    distance: '10 min ride',
    category: 'nightlife',
  },
  {
    id: 'feed-4',
    title: 'Yoga & Meditation',
    time: 'Tomorrow, 08:30',
    endTime: '09:30',
    location: 'Wellness Center',
    source: 'Yoga Collective',
    imageUrl: 'https://images.unsplash.com/photo-1750698544932-c7471990f1ca?w=800',
    attendees: 12,
    distance: '8 min walk',
    category: 'sports',
  },
  {
    id: 'feed-5',
    title: 'Beach Volleyball Tournament',
    time: 'Tomorrow, 15:00',
    endTime: '18:00',
    location: 'City Beach',
    source: 'Sports Club',
    imageUrl: 'https://images.unsplash.com/photo-1612872087720-bb876e2e67d1?w=800',
    friendsGoing: 7,
    distance: '15 min bike',
    category: 'sports',
  },
  {
    id: 'feed-6',
    title: 'Indie Rock Concert',
    time: 'Friday, 21:00',
    endTime: '23:30',
    location: 'The Warehouse',
    source: 'Music Collective',
    imageUrl: 'https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=800',
    attendees: 45,
    distance: '8 min walk',
    category: 'nightlife',
  },
  {
    id: 'feed-7',
    title: 'Startup Networking Brunch',
    time: 'Saturday, 11:00',
    endTime: '13:00',
    location: 'Innovation Hub',
    source: 'Entrepreneur Club',
    imageUrl: 'https://images.unsplash.com/photo-1556761175-b413da4baf72?w=800',
    friendsGoing: 2,
    distance: '6 min walk',
    category: 'university',
  },
  {
    id: 'feed-8',
    title: 'Rooftop BBQ & Chill',
    time: 'Saturday, 17:00',
    endTime: '22:00',
    location: 'Skyline Terrace',
    source: 'Friends Group',
    imageUrl: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800',
    friendsGoing: 12,
    distance: '10 min walk',
    category: 'nightlife',
  },
  {
    id: 'feed-9',
    title: 'Morning Hiking Adventure',
    time: 'Sunday, 07:00',
    endTime: '12:00',
    location: 'Mountain Trail',
    source: 'Outdoor Club',
    imageUrl: 'https://images.unsplash.com/photo-1551632811-561732d1e306?w=800',
    friendsGoing: 4,
    distance: '25 min drive',
    category: 'sports',
  },
  {
    id: 'feed-10',
    title: 'Electronic Music Night',
    time: 'Friday, 22:00',
    endTime: '04:00',
    location: 'Club Neon',
    source: 'Nightlife Crew',
    imageUrl: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800',
    attendees: 120,
    distance: '12 min ride',
    category: 'nightlife',
  },
];

const myFlowEvents = [
  { id: 'e1', time: '07:00', title: 'Morning Run', imageUrl: 'https://images.unsplash.com/photo-1699959560616-aa17ace76879?w=400' },
  { id: 'e2', time: '10:00', title: 'Study', imageUrl: 'https://images.unsplash.com/photo-1722248540590-ba8b7af1d7b2?w=400' },
];

// ===== FOMO BADGES (Variable Rewards) =====
const getFOMOBadge = (event: EventCardData, index: number) => {
  // Variable rewards: nicht jedes Event hat ein Badge
  const random = (event.id.charCodeAt(5) + index) % 5;
  
  if (event.friendsGoing && event.friendsGoing >= 5) {
    return { icon: Users, text: `${event.friendsGoing} friends going`, color: 'bg-green-500' };
  }
  
  if (random === 0 && event.attendees) {
    return { icon: Flame, text: 'Trending', color: 'bg-orange-500' };
  }
  
  if (random === 1) {
    return { icon: Zap, text: 'New', color: 'bg-blue-500' };
  }
  
  if (random === 2 && event.distance?.includes('walk')) {
    return { icon: Star, text: 'Near you', color: 'bg-purple-500' };
  }
  
  return null;
};

export function Dashboard({ notificationCount, onNotificationClick }: DashboardProps) {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [feedEvents, setFeedEvents] = useState<EventCardData[]>(createFeedEvents());
  const [selectedEvent, setSelectedEvent] = useState<EventDetail | null>(null);
  const [activeFilter, setActiveFilter] = useState<FeedFilter>('all');
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [savedEvents, setSavedEvents] = useState<Set<string>>(new Set());
  
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const loadMoreTriggerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // ===== INFINITE SCROLL (wie Instagram/TikTok) =====
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !isLoadingMore) {
          loadMoreEvents();
        }
      },
      { threshold: 0.5 }
    );

    if (loadMoreTriggerRef.current) {
      observer.observe(loadMoreTriggerRef.current);
    }

    return () => observer.disconnect();
  }, [isLoadingMore]);

  const loadMoreEvents = useCallback(() => {
    setIsLoadingMore(true);
    
    // Simuliere API call
    setTimeout(() => {
      const newEvents = createFeedEvents().map((e, i) => ({
        ...e,
        id: `${e.id}-${Date.now()}-${i}`,
      }));
      
      setFeedEvents(prev => [...prev, ...newEvents]);
      setIsLoadingMore(false);
    }, 800);
  }, []);

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      day: 'numeric',
      month: 'short',
    });
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    });
  };

  const handleAddToFlow = (eventId: string) => {
    console.log('Adding event to flow:', eventId);
    // Nicht sofort entfernen (wie Instagram - bleibt im Feed)
  };

  const handleSaveEvent = (eventId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSavedEvents(prev => {
      const newSet = new Set(prev);
      if (newSet.has(eventId)) {
        newSet.delete(eventId);
      } else {
        newSet.add(eventId);
      }
      return newSet;
    });
  };

  const currentHour = currentTime.getHours();
  const nextEvent = myFlowEvents.find(e => parseInt(e.time.split(':')[0]) > currentHour);
  const currentGap = nextEvent ? `Until ${nextEvent.time}` : 'Rest of day';
  
  // Filter events
  const filteredEvents = feedEvents.filter(event => {
    if (activeFilter === 'all') return true;
    return event.category === activeFilter;
  });

  // Count new opportunities (Trigger für Neugier)
  const newOpportunities = feedEvents.filter(e => 
    e.time.includes('Today') || e.time.includes('Tonight') || e.time.includes('Tomorrow')
  ).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-neutral-50 via-blue-50/30 to-green-50/20">
      {/* Header - Sticky */}
      <header className="sticky top-0 bg-white/80 backdrop-blur-lg z-20 px-6 pt-6 pb-4 border-b border-gray-100">
        <div className="flex justify-between items-start mb-3">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Home</h1>
            <p className="text-sm text-gray-500">Today · {formatDate(currentTime)}</p>
          </div>
          <button
            onClick={onNotificationClick}
            className="relative p-2 hover:bg-gray-100 rounded-full transition"
          >
            <Bell className="w-6 h-6 text-gray-700" />
            {notificationCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {notificationCount}
              </span>
            )}
          </button>
        </div>
      </header>

      <div ref={scrollContainerRef} className="overflow-y-auto scrollbar-hide pb-24">
        {/* ===== FLOW CARD (Ruhiger Planning Space) ===== */}
        <div className="px-6 py-5">
          <div className="glass-panel p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-semibold text-gray-900">My Flow</h2>
                <p className="text-xs text-gray-500 mt-0.5">{formatTime(currentTime)}</p>
              </div>
              <button className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1 font-medium">
                View week
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>

            {/* Current & Next Event (nur Information!) */}
            <div className="space-y-3">
              {/* Current or Free Time */}
              <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-[12px]">
                <Clock className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-blue-600 font-medium mb-1">Now</p>
                  <p className="text-sm font-semibold text-gray-900">
                    {currentHour < 7 ? 'Free time' : 
                     currentHour < 10 ? 'Morning Run' :
                     currentHour < 14 ? 'Study' :
                     'Free time'}
                  </p>
                  <p className="text-xs text-gray-500 mt-0.5">
                    {currentHour < 7 ? 'Until 07:00' :
                     currentHour < 10 ? '07:00 - 09:00' :
                     currentHour < 14 ? '10:00 - 14:00' :
                     currentGap}
                  </p>
                </div>
              </div>

              {/* Next Event */}
              {nextEvent && (
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-[12px]">
                  <ChevronRight className="w-5 h-5 text-gray-400 flex-shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-gray-500 font-medium mb-1">Next</p>
                    <p className="text-sm font-semibold text-gray-900">{nextEvent.title}</p>
                    <p className="text-xs text-gray-500 mt-0.5">{nextEvent.time}</p>
                  </div>
                  <div className="w-10 h-10 rounded-[8px] overflow-hidden shadow-sm flex-shrink-0">
                    <img src={nextEvent.imageUrl} alt={nextEvent.title} className="w-full h-full object-cover" />
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ===== FOR YOU FEED HEADER (Action Phase) ===== */}
        <div className="px-6 py-4 bg-gradient-to-b from-white/50 to-transparent">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-bold text-gray-900">For You</h2>
              <p className="text-sm text-gray-500">Handpicked für diese Woche</p>
            </div>
            
            <TrendingUp className="w-5 h-5 text-gray-400" />
          </div>

          {/* Quick Filters (wie Instagram Stories) */}
          <div className="flex gap-2 overflow-x-auto scrollbar-hide -mx-6 px-6">
            {(['all', 'sports', 'nightlife', 'university'] as FeedFilter[]).map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                  activeFilter === filter
                    ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/20'
                    : 'bg-white/60 text-gray-700 hover:bg-white'
                }`}
              >
                {filter === 'all' ? '✨ Alle' : 
                 filter === 'sports' ? '⚽ Sport' :
                 filter === 'nightlife' ? '🎉 Nightlife' :
                 '📚 Uni'}
              </button>
            ))}
          </div>
        </div>

        {/* ===== FEED CARDS (Variable Reward Phase) ===== */}
        <div className="px-6 space-y-4 pb-6">
          {filteredEvents.map((event, index) => {
            const fomoBadge = getFOMOBadge(event, index);
            const isSaved = savedEvents.has(event.id);

            return (
              <div
                key={event.id}
                className="relative bg-white rounded-[20px] overflow-hidden shadow-md hover:shadow-xl transition-all cursor-pointer group"
                onClick={() => setSelectedEvent(event as EventDetail)}
              >
                {/* FOMO Badge (oben links) */}
                {fomoBadge && (
                  <div className={`absolute top-4 left-4 z-10 ${fomoBadge.color} text-white px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-lg`}>
                    <fomoBadge.icon className="w-3.5 h-3.5" />
                    <span className="text-xs font-semibold">{fomoBadge.text}</span>
                  </div>
                )}

                {/* Save/Heart Button (oben rechts) */}
                <button
                  onClick={(e) => handleSaveEvent(event.id, e)}
                  className="absolute top-4 right-4 z-10 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-110"
                >
                  <Heart
                    className={`w-5 h-5 transition-all ${
                      isSaved ? 'fill-red-500 text-red-500' : 'text-gray-700'
                    }`}
                  />
                </button>

                {/* Hero Image (4:5 Ratio - Instagram Style) */}
                <div className="relative aspect-[4/5]">
                  <img
                    src={event.imageUrl}
                    alt={event.title}
                    className="w-full h-full object-cover"
                    style={{ filter: 'contrast(1.1) saturate(0.9)' }}
                  />
                  
                  {/* Duotone Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-blue-900/90 via-blue-800/50 to-transparent mix-blend-multiply" />
                  
                  {/* Grain */}
                  <div 
                    className="absolute inset-0 opacity-10 mix-blend-overlay"
                    style={{
                      backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence baseFrequency='0.8' /%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' /%3E%3C/svg%3E")`,
                    }}
                  />
                  
                  {/* Content Overlay (unten) */}
                  <div className="absolute bottom-0 left-0 right-0 p-5 space-y-3">
                    {/* Source */}
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-white/20 backdrop-blur-sm border border-white/30 rounded-full">
                      <span className="text-xs font-medium text-white">{event.source}</span>
                    </div>
                    
                    {/* Title */}
                    <h3 className="text-white text-2xl font-bold tracking-tight drop-shadow-lg">
                      {event.title}
                    </h3>
                    
                    {/* Meta Info */}
                    <div className="flex items-center gap-3 text-white/90">
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span className="text-sm font-medium">{event.time}</span>
                      </div>
                      
                      <div className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        <span className="text-sm">{event.location}</span>
                      </div>
                    </div>

                    {/* Social Proof */}
                    {event.friendsGoing ? (
                      <div className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-green-500/90 backdrop-blur-sm rounded-full">
                        <Users className="w-3.5 h-3.5 text-white" />
                        <span className="text-xs font-semibold text-white">
                          {event.friendsGoing} Freunde gehen hin
                        </span>
                      </div>
                    ) : event.attendees ? (
                      <div className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/20 backdrop-blur-sm border border-white/30 rounded-full">
                        <Users className="w-3.5 h-3.5 text-white" />
                        <span className="text-xs font-medium text-white">
                          {event.attendees} Teilnehmer
                        </span>
                      </div>
                    ) : null}
                  </div>
                </div>

                {/* Quick Action Strip (Investment Phase) */}
                <div className="p-4 bg-gradient-to-r from-blue-50 to-purple-50">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleAddToFlow(event.id);
                    }}
                    className="w-full px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-[16px] font-medium shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2 transition-all hover:scale-105 active:scale-95"
                  >
                    <Sparkles className="w-5 h-5" />
                    <span>In Kalender eintragen</span>
                  </button>
                </div>
              </div>
            );
          })}

          {/* Loading Indicator (Infinite Scroll) */}
          <div ref={loadMoreTriggerRef} className="py-8">
            {isLoadingMore && (
              <div className="flex flex-col items-center gap-3">
                <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
                <p className="text-sm text-gray-500">Lade weitere Events...</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Event Detail Modal */}
      {selectedEvent && (
        <EventDetailModal
          event={selectedEvent}
          onClose={() => setSelectedEvent(null)}
          onAddToCalendar={(id) => {
            handleAddToFlow(id);
            setSelectedEvent(null);
          }}
        />
      )}
    </div>
  );
}