import { X, Users, MapPin, Clock, Navigation, Sparkles, Check, ChevronRight, MoreHorizontal, CheckCircle, AlertCircle } from 'lucide-react';
import { useState, useEffect } from 'react';

// ===== TYPES =====

type UpdateEvent = {
  id: string;
  title: string;
  type: 'social' | 'personal';
  source: {
    type: 'crew' | 'person';
    name: string;
    avatar?: string;
  };
  timestamp: string; // "2h ago"
  imageUrl?: string; // for social events
  icon?: string; // for personal blocks
  time: string;
  endTime: string;
  location: string;
  distance?: string;
  friendsGoing?: number;
  conflict?: {
    title: string;
    time: string;
  };
};

type UpdatesInboxSheetProps = {
  onClose: () => void;
  onEventAdded: (id: string) => void;
  onEventDismissed: (id: string) => void;
};

// ===== MOCK DATA =====

const mockUpdates: UpdateEvent[] = [
  {
    id: 'update-1',
    title: 'Sunset 10K Run',
    type: 'social',
    source: {
      type: 'crew',
      name: 'Running Group',
    },
    timestamp: '2h ago',
    imageUrl: 'https://images.unsplash.com/photo-1699959560616-aa17ace76879?w=800',
    time: '18:00',
    endTime: '19:30',
    location: 'Central Park',
    distance: '12 min walk',
    friendsGoing: 3,
  },
  {
    id: 'update-2',
    title: 'Coffee & Code Meetup',
    type: 'social',
    source: {
      type: 'crew',
      name: 'CS Department',
    },
    timestamp: '5h ago',
    imageUrl: 'https://images.unsplash.com/photo-1623121181613-eeced17aea39?w=800',
    time: '14:00',
    endTime: '16:00',
    location: 'Campus Library',
    distance: '5 min walk',
  },
  {
    id: 'update-3',
    title: 'Downtown Bar Crawl',
    type: 'social',
    source: {
      type: 'crew',
      name: 'Party Crew',
    },
    timestamp: '1d ago',
    imageUrl: 'https://images.unsplash.com/photo-1759870075384-4e82adc2f679?w=800',
    time: '20:00',
    endTime: '23:00',
    location: 'City Center',
    distance: '10 min ride',
    friendsGoing: 5,
    conflict: {
      title: 'Study Session',
      time: '18:00',
    },
  },
];

// ===== MAIN COMPONENT =====

export function UpdatesInboxSheet({ onClose, onEventAdded, onEventDismissed }: UpdatesInboxSheetProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [state, setState] = useState<'default' | 'conflict' | 'added'>('default');
  const [showUndo, setShowUndo] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);

  const currentUpdate = mockUpdates[currentIndex];
  const hasConflict = !!currentUpdate?.conflict;

  // Reset state when switching updates
  useEffect(() => {
    if (hasConflict) {
      setState('conflict');
    } else {
      setState('default');
    }
    setShowUndo(false);
    setShowMoreMenu(false);
  }, [currentIndex, hasConflict]);

  // Undo timer
  useEffect(() => {
    if (showUndo) {
      const timer = setTimeout(() => {
        setShowUndo(false);
        handleNext();
      }, 8000);
      return () => clearTimeout(timer);
    }
  }, [showUndo]);

  if (!currentUpdate) {
    onClose();
    return null;
  }

  // ===== HANDLERS =====

  const handleAddToCalendar = () => {
    setIsAnimating(true);
    
    setTimeout(() => {
      setState('added');
      setShowUndo(true);
      onEventAdded(currentUpdate.id);
      setIsAnimating(false);
    }, 600);
  };

  const handleUndo = () => {
    setState(hasConflict ? 'conflict' : 'default');
    setShowUndo(false);
    // In real app: remove from calendar
  };

  const handleLater = () => {
    onEventDismissed(currentUpdate.id);
    handleNext();
  };

  const handleNext = () => {
    if (currentIndex < mockUpdates.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      onClose();
    }
  };

  const totalUpdates = mockUpdates.length;
  const progressPercent = ((currentIndex + 1) / totalUpdates) * 100;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div
        className={`w-full max-w-md bg-gradient-to-b from-neutral-50 to-white rounded-t-[28px] shadow-2xl animate-slide-up ${
          isAnimating ? 'animate-fly-to-calendar' : ''
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Progress Bar (sehr subtil) */}
        <div className="h-1 bg-gray-100 rounded-t-[28px] overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-blue-500 to-blue-600 transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* ===== HEADER ===== */}
        <div className="px-6 pt-5 pb-4 border-b border-gray-100">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h2 className="text-xl font-bold text-gray-900 mb-1">
                Updates von deinen Crews
              </h2>
              <p className="text-sm text-gray-600">
                Ein Tap – und es steht in deinem Kalender.
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              <span className="text-xs font-medium text-gray-400">
                {currentIndex + 1} von {totalUpdates}
              </span>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                style={{ minWidth: '44px', minHeight: '44px' }}
              >
                <X className="w-5 h-5 text-gray-700" />
              </button>
            </div>
          </div>
        </div>

        {/* ===== EVENT PREVIEW CARD ===== */}
        <div className="px-6 py-5 space-y-4">
          {/* Source Row */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              {/* Avatar */}
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold text-sm shadow-md">
                {currentUpdate.source.name.charAt(0)}
              </div>
              
              <div>
                <p className="text-sm font-semibold text-gray-900">
                  {currentUpdate.source.name}
                </p>
                <p className="text-xs text-gray-500">
                  {currentUpdate.timestamp}
                </p>
              </div>
            </div>
          </div>

          {/* Event Poster/Preview */}
          {currentUpdate.type === 'social' && currentUpdate.imageUrl ? (
            // SOCIAL EVENT → Poster Cover Card
            <div className="relative aspect-[16/9] rounded-[20px] overflow-hidden shadow-lg">
              <img
                src={currentUpdate.imageUrl}
                alt={currentUpdate.title}
                className="w-full h-full object-cover"
                style={{ filter: 'contrast(1.1) saturate(0.9)' }}
              />
              
              {/* Duotone Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-blue-900/80 via-blue-800/40 to-transparent mix-blend-multiply" />
              
              {/* Grain Texture */}
              <div 
                className="absolute inset-0 opacity-10 mix-blend-overlay"
                style={{
                  backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence baseFrequency='0.8' /%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' /%3E%3C/svg%3E")`,
                }}
              />
              
              {/* Title Overlay */}
              <div className="absolute bottom-0 left-0 right-0 p-5">
                <h3 className="text-white text-2xl font-bold tracking-tight mb-2 drop-shadow-lg">
                  {currentUpdate.title}
                </h3>
                
                {/* Social Proof Chip (klein, sekundär) */}
                {currentUpdate.friendsGoing && (
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-white/20 backdrop-blur-sm border border-white/30 rounded-full">
                    <Users className="w-3 h-3 text-white" />
                    <span className="text-xs font-medium text-white">
                      {currentUpdate.friendsGoing} Freunde gehen hin
                    </span>
                  </div>
                )}
              </div>
            </div>
          ) : (
            // PERSONAL BLOCK → Icon Card
            <div className="h-32 bg-gradient-to-br from-purple-500 to-purple-600 rounded-[20px] p-4 flex items-center gap-3 shadow-lg">
              <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center text-2xl border-2 border-white/30">
                {currentUpdate.icon || '📅'}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-white text-xl font-bold tracking-tight mb-1 line-clamp-1">
                  {currentUpdate.title}
                </h3>
                <div className="flex items-center gap-2 text-white/90">
                  <Clock className="w-4 h-4" />
                  <span className="text-sm font-medium">
                    {currentUpdate.time} - {currentUpdate.endTime}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Meta Row */}
          <div className="flex items-center gap-4 text-sm text-gray-700">
            <div className="flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-gray-500" />
              <span className="font-semibold">{currentUpdate.time} – {currentUpdate.endTime}</span>
            </div>
            
            <div className="flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-gray-500" />
              <span>{currentUpdate.location}</span>
            </div>
          </div>

          {currentUpdate.distance && (
            <div className="flex items-center gap-1.5 text-sm text-gray-600">
              <Navigation className="w-4 h-4 text-gray-500" />
              <span className="font-medium">{currentUpdate.distance}</span>
            </div>
          )}

          {/* ===== STATUS LINE (entscheidend!) ===== */}
          {state !== 'added' && (
            <div className={`flex items-center gap-2 px-4 py-2.5 rounded-[12px] ${
              hasConflict 
                ? 'bg-orange-50 border border-orange-200' 
                : 'bg-green-50 border border-green-200'
            }`}>
              {hasConflict ? (
                <>
                  <AlertCircle className="w-4 h-4 text-orange-600 flex-shrink-0" />
                  <span className="text-sm font-medium text-orange-900">
                    Konflikt mit {currentUpdate.conflict?.title} ({currentUpdate.conflict?.time})
                  </span>
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
                  <span className="text-sm font-medium text-green-900">
                    Keine Konflikte
                  </span>
                </>
              )}
            </div>
          )}

          {/* ===== CTA ZONE ===== */}
          <div className="pt-2">
            {state === 'added' ? (
              // STATE C: Added
              <div className="space-y-3">
                <button
                  onClick={handleNext}
                  className="w-full px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-[16px] font-medium shadow-lg shadow-green-500/20 flex items-center justify-center gap-2 transition-all hover:scale-105"
                >
                  <Check className="w-5 h-5" />
                  <span>Im Kalender ✓</span>
                </button>
                
                {showUndo && (
                  <button
                    onClick={handleUndo}
                    className="w-full text-sm text-gray-600 hover:text-gray-900 transition-colors py-2 font-medium"
                  >
                    Rückgängig machen
                  </button>
                )}
              </div>
            ) : (
              // STATE A/B: Default or Conflict
              <>
                <button
                  onClick={handleAddToCalendar}
                  className="w-full px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-[16px] font-medium shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2 transition-all hover:scale-105 active:scale-95"
                >
                  <Sparkles className="w-5 h-5" />
                  <span>In Kalender eintragen</span>
                </button>
                
                {/* Microcopy unter Button */}
                <p className="text-xs text-center text-gray-500 mt-2">
                  Trägt {currentUpdate.time}–{currentUpdate.endTime} in deine Woche ein
                </p>
              </>
            )}
          </div>

          {/* ===== SECONDARY ACTIONS ===== */}
          {state !== 'added' && (
            <div className="flex flex-col gap-2 pt-2">
              <button
                onClick={handleLater}
                className="w-full text-sm text-gray-600 hover:text-gray-900 transition-colors py-2 font-medium"
              >
                Später
              </button>
              
              <div className="relative">
                <button
                  onClick={() => setShowMoreMenu(!showMoreMenu)}
                  className="w-full flex items-center justify-center gap-1 text-xs text-gray-500 hover:text-gray-700 transition-colors py-2"
                >
                  <MoreHorizontal className="w-4 h-4" />
                  <span>Mehr Optionen</span>
                </button>

                {/* More Menu */}
                {showMoreMenu && (
                  <div className="absolute bottom-full left-0 right-0 mb-2 bg-white rounded-[12px] shadow-lg border border-gray-200 py-2 z-10">
                    <button className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                      {currentUpdate.source.name} stummschalten
                    </button>
                    <button className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                      Diese Art ausblenden
                    </button>
                    <button className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 transition-colors">
                      Melden
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Bottom Padding */}
        <div className="h-6" />
      </div>
    </div>
  );
}
