import { Sparkles, Share2, MoreVertical, Clock, MapPin, Users } from 'lucide-react';
import { useState } from 'react';

type MyEvent = {
  id: string;
  title: string;
  time: string;
  endTime: string;
  location: string;
  imageUrl: string;
  status: 'draft' | 'published';
  attendees: number;
};

const mockEvents: MyEvent[] = [
  {
    id: '1',
    title: 'Weekend Hike Trip',
    time: 'Sat, 10:00',
    endTime: '15:00',
    location: 'Mountain Trail',
    imageUrl: 'https://images.unsplash.com/photo-1699959560616-aa17ace76879?w=800',
    status: 'published',
    attendees: 8,
  },
  {
    id: '2',
    title: 'Study Group Session',
    time: 'Wed, 14:00',
    endTime: '16:00',
    location: 'Library Room 3',
    imageUrl: 'https://images.unsplash.com/photo-1722248540590-ba8b7af1d7b2?w=800',
    status: 'draft',
    attendees: 0,
  },
];

export function MyEvents() {
  const [events] = useState<MyEvent[]>(mockEvents);
  const [menuOpen, setMenuOpen] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-white pb-6">
      {/* Header */}
      <header className="sticky top-0 bg-white/80 backdrop-blur-lg z-10 px-6 pt-6 pb-4 border-b border-gray-100">
        <h1>My Events</h1>
        <p className="text-sm text-gray-500 mt-1">Events you're hosting</p>
      </header>

      {/* Events List */}
      <div className="px-6 py-6 space-y-4">
        {events.map((event) => (
          <div
            key={event.id}
            className="bg-white rounded-[20px] overflow-hidden shadow-md hover:shadow-lg transition-all"
          >
            {/* Cover Image */}
            <div className="relative h-40">
              <img
                src={event.imageUrl}
                alt={event.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
              
              {/* Status Badge */}
              {event.status === 'draft' && (
                <div className="absolute top-3 left-3 bg-yellow-500 text-white text-xs px-3 py-1 rounded-full">
                  Draft
                </div>
              )}

              {/* Menu */}
              <div className="absolute top-3 right-3">
                <button
                  onClick={() => setMenuOpen(menuOpen === event.id ? null : event.id)}
                  className="p-2 bg-white/90 backdrop-blur rounded-full hover:bg-white transition"
                >
                  <MoreVertical className="w-4 h-4 text-gray-700" />
                </button>
                
                {menuOpen === event.id && (
                  <div className="absolute right-0 top-12 bg-white rounded-[16px] shadow-xl p-2 min-w-[150px] animate-fade-in">
                    <button className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg">
                      Edit
                    </button>
                    <button className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg">
                      Delete
                    </button>
                  </div>
                )}
              </div>

              {/* Title */}
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <h3 className="text-white">{event.title}</h3>
              </div>
            </div>

            {/* Event Info */}
            <div className="p-4 space-y-3">
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-gray-500" />
                  <span>{event.time} - {event.endTime}</span>
                </div>
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4 text-gray-500" />
                  <span>{event.location}</span>
                </div>
              </div>

              {event.attendees > 0 && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Users className="w-4 h-4 text-gray-500" />
                  <span>{event.attendees} attending</span>
                </div>
              )}

              {/* Primary Action */}
              <button className="w-full btn-power">
                <Share2 className="w-5 h-5" />
                <span className="font-medium">Share & Invite</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* FAB for Creating New Event */}
      <button className="fixed bottom-24 right-6 w-14 h-14 btn-power rounded-full shadow-2xl flex items-center justify-center">
        <Sparkles className="w-6 h-6 text-white" />
      </button>
    </div>
  );
}