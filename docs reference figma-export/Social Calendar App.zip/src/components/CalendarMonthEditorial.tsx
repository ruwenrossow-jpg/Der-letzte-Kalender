import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useState } from 'react';

type CalendarTheme = 'daylight' | 'neon' | 'paper';

type MonthEvent = {
  id: string;
  title: string;
  date: number; // 1-31
  startHour: number;
  startMinute: number;
  endHour: number;
  endMinute: number;
  imageUrl?: string;
  type: 'social' | 'personal' | 'all-day';
  icon?: string;
  color?: string;
  allDayType?: 'out-of-office' | 'holiday' | 'birthday' | 'multi-day' | 'todo';
};

// ===== LIFESTYLE ICONS =====
const LifestyleIcon = ({ type, className }: { type: string; className?: string }) => {
  const iconMap: Record<string, string> = {
    work: '✦',
    study: '◆',
    focus: '◈',
    meeting: '◉',
    gym: '◊',
    yoga: '✧',
    run: '◈',
    coffee: '◐',
    food: '◑',
    shopping: '◒',
    travel: '◓',
  };

  return (
    <div className={className}>
      {iconMap[type] || '◆'}
    </div>
  );
};

// ===== MOCK DATA =====
const mockMonthEvents: MonthEvent[] = [
  // Day 22 (Mon)
  { id: 'm1', title: 'Morning Run', date: 22, startHour: 7, startMinute: 0, endHour: 8, endMinute: 0, imageUrl: 'https://images.unsplash.com/photo-1699959560616-aa17ace76879?w=400', type: 'social' },
  { id: 'm2', title: 'Deep Work', date: 22, startHour: 10, startMinute: 0, endHour: 12, endMinute: 0, icon: 'work', color: 'from-blue-500 to-blue-600', type: 'personal' },
  { id: 'm3', title: 'Out of Office', date: 22, startHour: 0, startMinute: 0, endHour: 0, endMinute: 0, type: 'all-day', allDayType: 'out-of-office' },
  
  // Day 23 (Tue)
  { id: 'm4', title: 'Yoga Flow', date: 23, startHour: 8, startMinute: 30, endHour: 9, endMinute: 30, imageUrl: 'https://images.unsplash.com/photo-1750698544932-c7471990f1ca?w=400', type: 'social' },
  { id: 'm5', title: 'Study Session', date: 23, startHour: 14, startMinute: 0, endHour: 16, endMinute: 0, icon: 'study', color: 'from-purple-500 to-purple-600', type: 'personal' },
  { id: 'm6', title: 'Christmas', date: 23, startHour: 0, startMinute: 0, endHour: 0, endMinute: 0, type: 'all-day', allDayType: 'holiday' },
  
  // Day 24 (Wed)
  { id: 'm7', title: 'Coffee & Code', date: 24, startHour: 14, startMinute: 0, endHour: 16, endMinute: 0, imageUrl: 'https://images.unsplash.com/photo-1623121181613-eeced17aea39?w=400', type: 'social' },
  { id: 'm8', title: "Mom's Birthday", date: 24, startHour: 0, startMinute: 0, endHour: 0, endMinute: 0, type: 'all-day', allDayType: 'birthday' },
  
  // Day 26 (Fri)
  { id: 'm9', title: 'Bar Night', date: 26, startHour: 20, startMinute: 0, endHour: 23, endMinute: 0, imageUrl: 'https://images.unsplash.com/photo-1759870075384-4e82adc2f679?w=400', type: 'social' },
  { id: 'm10', title: 'Submit report', date: 26, startHour: 0, startMinute: 0, endHour: 0, endMinute: 0, type: 'all-day', allDayType: 'todo' },
  
  // Day 27 (Sat)
  { id: 'm11', title: 'Tennis Match', date: 27, startHour: 16, startMinute: 0, endHour: 17, endMinute: 30, imageUrl: 'https://images.unsplash.com/photo-1494251202008-582bbc3eac69?w=400', type: 'social' },
  
  // Day 28 (Sun)
  { id: 'm12', title: 'Team Meeting', date: 28, startHour: 17, startMinute: 0, endHour: 18, endMinute: 0, icon: 'meeting', color: 'from-gray-500 to-gray-600', type: 'personal' },
];

const themes = {
  daylight: {
    name: 'Daylight Editorial',
    background: 'bg-gradient-to-br from-gray-50 via-blue-50/30 to-green-50/20',
    headerBg: 'bg-white/80',
    headerText: 'text-gray-900',
    headerBorder: 'border-gray-200/30',
    dayHeaderText: 'text-gray-500',
    dayBoxBg: 'bg-white/60',
    dayBoxBorder: 'border-white/40',
    dayBoxShadow: 'shadow-sm shadow-blue-500/5',
    dayBoxHover: 'hover:bg-white/80 hover:shadow-md',
    todayBg: 'bg-blue-500',
    todayText: 'text-white',
    dayText: 'text-gray-900',
    eventDot: 'bg-blue-500',
    allDayTag: {
      'out-of-office': 'bg-red-100 border-red-200 text-red-700',
      'holiday': 'bg-green-100 border-green-200 text-green-700',
      'birthday': 'bg-pink-100 border-pink-200 text-pink-700',
      'multi-day': 'bg-blue-100 border-blue-200 text-blue-700',
      'todo': 'bg-gray-100 border-gray-200 text-gray-700',
    },
    textSecondary: 'text-gray-600',
  },
  neon: {
    name: 'Neon Night',
    background: 'bg-gradient-to-br from-gray-950 via-purple-950/30 to-pink-950/20',
    headerBg: 'bg-gray-900/80',
    headerText: 'text-white',
    headerBorder: 'border-purple-500/20',
    dayHeaderText: 'text-gray-400',
    dayBoxBg: 'bg-gray-900/60',
    dayBoxBorder: 'border-purple-500/20',
    dayBoxShadow: 'shadow-sm shadow-purple-500/10',
    dayBoxHover: 'hover:bg-gray-900/80 hover:shadow-md',
    todayBg: 'bg-gradient-to-r from-purple-500 to-pink-500',
    todayText: 'text-white',
    dayText: 'text-white',
    eventDot: 'bg-pink-500',
    allDayTag: {
      'out-of-office': 'bg-red-900/60 border-red-500/40 text-red-300',
      'holiday': 'bg-green-900/60 border-green-500/40 text-green-300',
      'birthday': 'bg-pink-900/60 border-pink-500/40 text-pink-300',
      'multi-day': 'bg-blue-900/60 border-blue-500/40 text-blue-300',
      'todo': 'bg-gray-800/60 border-gray-600/40 text-gray-300',
    },
    textSecondary: 'text-gray-300',
  },
  paper: {
    name: 'Warm Paper',
    background: 'bg-gradient-to-br from-amber-50 via-orange-50/40 to-amber-100/30',
    headerBg: 'bg-white/80',
    headerText: 'text-amber-900',
    headerBorder: 'border-amber-200/30',
    dayHeaderText: 'text-amber-600',
    dayBoxBg: 'bg-white/50',
    dayBoxBorder: 'border-amber-200/40',
    dayBoxShadow: 'shadow-sm shadow-amber-500/5',
    dayBoxHover: 'hover:bg-white/80 hover:shadow-md',
    todayBg: 'bg-gradient-to-r from-orange-400 to-amber-500',
    todayText: 'text-white',
    dayText: 'text-amber-900',
    eventDot: 'bg-orange-500',
    allDayTag: {
      'out-of-office': 'bg-red-50 border-red-200 text-red-800',
      'holiday': 'bg-green-50 border-green-200 text-green-800',
      'birthday': 'bg-pink-50 border-pink-200 text-pink-800',
      'multi-day': 'bg-blue-50 border-blue-200 text-blue-800',
      'todo': 'bg-gray-50 border-gray-200 text-gray-800',
    },
    textSecondary: 'text-amber-800',
  },
};

type MonthCanvasProps = {
  theme: CalendarTheme;
};

export function MonthCanvasEditorial({ theme }: MonthCanvasProps) {
  const [currentMonth, setCurrentMonth] = useState(11); // December = 11
  const [currentYear, setCurrentYear] = useState(2024);
  
  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  
  const themeConfig = themes[theme];
  
  // Get first day of month (0 = Sunday, 1 = Monday, etc.)
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
  const startOffset = firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1; // Convert to Mon=0
  
  // Get days in month
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  
  // Today's date for highlighting
  const today = new Date();
  const isCurrentMonth = currentMonth === today.getMonth() && currentYear === today.getFullYear();
  const currentDay = isCurrentMonth ? today.getDate() : null;
  
  // Navigate months
  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };
  
  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };
  
  // Get events for a specific date
  const getEventsForDate = (date: number) => {
    return mockMonthEvents.filter(e => e.date === date);
  };
  
  // Get event icon/color for mini display
  const getEventIcon = (event: MonthEvent) => {
    if (event.type === 'all-day') {
      const icons = {
        'out-of-office': '🚫',
        'holiday': '⭐',
        'birthday': '🎂',
        'multi-day': '📅',
        'todo': '📝',
      };
      return icons[event.allDayType!] || '•';
    }
    
    if (event.type === 'social') {
      return '◉'; // Social dot
    }
    
    return event.icon || 'work';
  };

  return (
    <div className={`${themeConfig.background} min-h-screen transition-colors duration-300 relative overflow-hidden pb-6`}>
      {/* Grain Texture Overlay */}
      <div 
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='200' height='200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' /%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' /%3E%3C/svg%3E")`,
        }}
      />

      {/* ===== STICKY HEADER mit Month Navigation ===== */}
      <div className={`sticky top-0 z-30 px-4 py-4 ${themeConfig.headerBg} backdrop-blur-lg border-b ${themeConfig.headerBorder}`}>
        <div className="flex items-center justify-between max-w-6xl mx-auto">
          {/* Left: Month + Year */}
          <div>
            <h2 className={`text-xl font-bold ${themeConfig.headerText}`}>
              {monthNames[currentMonth]} {currentYear}
            </h2>
            <p className={`text-xs ${themeConfig.textSecondary} mt-0.5`}>
              {daysInMonth} days
            </p>
          </div>
          
          {/* Right: Navigation */}
          <div className="flex items-center gap-2">
            <button 
              onClick={handlePrevMonth}
              className={`p-2 rounded-full transition hover:bg-white/60`}
            >
              <ChevronLeft className={`w-5 h-5 ${themeConfig.headerText}`} />
            </button>
            
            <button 
              onClick={handleNextMonth}
              className={`p-2 rounded-full transition hover:bg-white/60`}
            >
              <ChevronRight className={`w-5 h-5 ${themeConfig.headerText}`} />
            </button>
          </div>
        </div>
      </div>

      {/* ===== CALENDAR GRID ===== */}
      <div className="px-4 pt-6 max-w-6xl mx-auto">
        {/* Day Headers (Mon-Sun) */}
        <div className="grid grid-cols-7 gap-2 mb-3">
          {dayNames.map((day, i) => (
            <div key={i} className="text-center">
              <p className={`text-xs font-semibold ${themeConfig.dayHeaderText}`}>
                {day}
              </p>
            </div>
          ))}
        </div>
        
        {/* Days Grid */}
        <div className="grid grid-cols-7 gap-2">
          {/* Empty cells before first day */}
          {Array.from({ length: startOffset }).map((_, i) => (
            <div key={`empty-${i}`} className="aspect-square" />
          ))}
          
          {/* Actual days */}
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const date = i + 1;
            const isToday = date === currentDay;
            const events = getEventsForDate(date);
            const allDayEvents = events.filter(e => e.type === 'all-day');
            const timedEvents = events.filter(e => e.type !== 'all-day');
            
            return (
              <div
                key={date}
                className={`aspect-square rounded-[16px] ${themeConfig.dayBoxBg} ${themeConfig.dayBoxBorder} ${themeConfig.dayBoxShadow} backdrop-blur-xl border overflow-hidden cursor-pointer transition-all ${themeConfig.dayBoxHover}`}
              >
                <div className="h-full flex flex-col p-2">
                  {/* Date Number */}
                  <div className="flex items-center justify-between mb-1.5">
                    <span className={`text-sm font-bold ${
                      isToday 
                        ? `${themeConfig.todayBg} ${themeConfig.todayText} w-6 h-6 rounded-full flex items-center justify-center text-xs`
                        : themeConfig.dayText
                    }`}>
                      {date}
                    </span>
                    
                    {/* Event Count Badge */}
                    {events.length > 0 && (
                      <div className={`w-4 h-4 ${themeConfig.eventDot} rounded-full flex items-center justify-center`}>
                        <span className="text-white text-[8px] font-bold">
                          {events.length}
                        </span>
                      </div>
                    )}
                  </div>
                  
                  {/* Events Preview */}
                  <div className="flex-1 space-y-1 overflow-hidden">
                    {/* All-Day Events (Tags) */}
                    {allDayEvents.slice(0, 1).map((event) => (
                      <div
                        key={event.id}
                        className={`text-[7px] px-1.5 py-0.5 rounded border ${
                          themeConfig.allDayTag[event.allDayType!]
                        } truncate`}
                      >
                        {getEventIcon(event)} {event.title.slice(0, 8)}
                      </div>
                    ))}
                    
                    {/* Timed Events (Dots/Icons) */}
                    {timedEvents.slice(0, 3).map((event) => (
                      <div
                        key={event.id}
                        className="flex items-center gap-1"
                      >
                        {event.type === 'social' ? (
                          <div className={`w-1.5 h-1.5 rounded-full ${themeConfig.eventDot}`} />
                        ) : (
                          <div className={`w-3 h-3 bg-gradient-to-br ${event.color} rounded-full flex items-center justify-center`}>
                            <LifestyleIcon type={event.icon || 'work'} className="text-white text-[6px]" />
                          </div>
                        )}
                        <span className={`text-[7px] ${themeConfig.textSecondary} truncate flex-1`}>
                          {event.startHour.toString().padStart(2, '0')}:{event.startMinute.toString().padStart(2, '0')} {event.title.slice(0, 6)}
                        </span>
                      </div>
                    ))}
                    
                    {/* +X more indicator */}
                    {events.length > 4 && (
                      <div className={`text-[7px] ${themeConfig.textSecondary} font-medium`}>
                        +{events.length - 4} more
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
