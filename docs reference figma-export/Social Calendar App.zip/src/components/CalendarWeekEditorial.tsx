import { ChevronLeft, ChevronRight, Clock } from 'lucide-react';
import { useState } from 'react';

type CalendarTheme = 'daylight' | 'neon' | 'paper';

type WeekEvent = {
  id: string;
  title: string;
  day: number; // 0-6 for Mon-Sun
  startHour: number;
  startMinute: number;
  endHour: number;
  endMinute: number;
  imageUrl?: string;
  location: string;
  type: 'social' | 'personal';
  icon?: string;
  color?: string;
  isHighlight?: boolean;
};

// ===== ALL-DAY EVENTS (Ganztägige Termine) =====
type AllDayEvent = {
  id: string;
  title: string;
  day: number; // 0-6 for Mon-Sun
  type: 'out-of-office' | 'holiday' | 'birthday' | 'multi-day' | 'todo';
  color?: string;
  icon?: string;
};

// ===== LIFESTYLE ICONS (Symbole statt Emojis) =====
const LifestyleIcon = ({ type, className }: { type: string; className?: string }) => {
  const iconMap: Record<string, string> = {
    // Produktivität
    work: '✦',
    study: '◆',
    focus: '◈',
    meeting: '◉',
    
    // Sport & Wellness
    gym: '◊',
    yoga: '✧',
    run: '◈',
    
    // Lifestyle
    coffee: '◐',
    food: '◑',
    shopping: '◒',
    travel: '◓',
  };

  return (
    <div className={className}>
      {iconMap[type] || '◆'}
    </div>
  );
};

const mockWeekEvents: WeekEvent[] = [
  // Monday
  { id: 'w1', title: 'Morning Run', day: 0, startHour: 7, startMinute: 0, endHour: 8, endMinute: 0, imageUrl: 'https://images.unsplash.com/photo-1699959560616-aa17ace76879?w=400', location: 'Park', type: 'social', isHighlight: true },
  { id: 'w2', title: 'Deep Work', day: 0, startHour: 10, startMinute: 0, endHour: 12, endMinute: 0, icon: 'work', color: 'from-blue-500 to-blue-600', location: 'Office', type: 'personal' },
  { id: 'w3', title: 'Tennis Match', day: 0, startHour: 16, startMinute: 0, endHour: 17, endMinute: 30, imageUrl: 'https://images.unsplash.com/photo-1494251202008-582bbc3eac69?w=400', location: 'Court', type: 'social' },
  
  // Tuesday
  { id: 'w4', title: 'Yoga Flow', day: 1, startHour: 8, startMinute: 30, endHour: 9, endMinute: 30, imageUrl: 'https://images.unsplash.com/photo-1750698544932-c7471990f1ca?w=400', location: 'Studio', type: 'social', isHighlight: true },
  { id: 'w5', title: 'Study Session', day: 1, startHour: 14, startMinute: 0, endHour: 16, endMinute: 0, icon: 'study', color: 'from-purple-500 to-purple-600', location: 'Library', type: 'personal' },
  { id: 'w6', title: 'Team Meeting', day: 1, startHour: 17, startMinute: 0, endHour: 18, endMinute: 0, icon: 'meeting', color: 'from-gray-500 to-gray-600', location: 'Zoom', type: 'personal' },
  
  // Wednesday
  { id: 'w7', title: 'Coffee & Code', day: 2, startHour: 14, startMinute: 0, endHour: 16, endMinute: 0, imageUrl: 'https://images.unsplash.com/photo-1623121181613-eeced17aea39?w=400', location: 'Cafe', type: 'social' },
  
  // Friday
  { id: 'w8', title: 'Bar Night', day: 4, startHour: 20, startMinute: 0, endHour: 23, endMinute: 0, imageUrl: 'https://images.unsplash.com/photo-1759870075384-4e82adc2f679?w=400', location: 'Downtown', type: 'social' },
  
  // Neue Events für proportionale Größen-Test
  { id: 'w9', title: 'Quick Call', day: 3, startHour: 9, startMinute: 0, endHour: 9, endMinute: 30, icon: 'meeting', color: 'from-blue-500 to-blue-600', location: 'Phone', type: 'personal' },
  { id: 'w10', title: 'Lunch', day: 3, startHour: 12, startMinute: 0, endHour: 13, endMinute: 30, icon: 'food', color: 'from-orange-500 to-orange-600', location: 'Restaurant', type: 'personal' },
];

// ===== MOCK ALL-DAY EVENTS =====
const mockAllDayEvents: AllDayEvent[] = [
  { id: 'ad1', title: 'Out of Office', day: 0, type: 'out-of-office' },
  { id: 'ad2', title: 'Christmas', day: 1, type: 'holiday' },
  { id: 'ad3', title: 'Mom\'s Birthday 🎂', day: 2, type: 'birthday' },
  { id: 'ad4', title: 'Zurich Design Days', day: 2, type: 'multi-day' },
  { id: 'ad5', title: 'Submit report', day: 4, type: 'todo' },
];

const themes = {
  daylight: {
    name: 'Daylight Editorial',
    background: 'bg-gradient-to-br from-gray-50 via-blue-50/30 to-green-50/20',
    glassBg: 'bg-white/60',
    glassBlur: 'backdrop-blur-xl',
    glassBorder: 'border-white/40',
    glassShadow: 'shadow-lg shadow-blue-500/5',
    timeRailBg: 'bg-white/40 backdrop-blur-xl',
    timeRailText: 'text-gray-600',
    gridLine: 'border-gray-200/30',
    weekStripBg: 'bg-white/80 backdrop-blur-lg',
    weekDayActive: 'bg-blue-500 text-white',
    weekDayInactive: 'bg-white/60 text-gray-600',
    moodDot: 'bg-green-400',
    nowLine: 'bg-blue-500',
    nowChipBg: 'bg-blue-500',
    nowChipText: 'text-white',
    posterFilter: 'contrast-110 saturate-90',
    posterOverlay: 'from-blue-900/80 via-blue-800/50 to-transparent',
    posterBorder: 'border-blue-200/40',
    iconCardBg: 'bg-gradient-to-br',
    iconCardText: 'text-white',
    iconCardShadow: 'shadow-md',
    memoryFrame: 'ring-2 ring-blue-400/60 shadow-xl shadow-blue-500/20',
    textPrimary: 'text-gray-900',
    textSecondary: 'text-gray-600',
    dayHeaderText: 'text-gray-700',
  },
  neon: {
    name: 'Neon Night',
    background: 'bg-gradient-to-br from-gray-950 via-purple-950/30 to-pink-950/20',
    glassBg: 'bg-gray-900/60',
    glassBlur: 'backdrop-blur-xl',
    glassBorder: 'border-purple-500/20',
    glassShadow: 'shadow-lg shadow-purple-500/10',
    timeRailBg: 'bg-gray-950/40 backdrop-blur-xl',
    timeRailText: 'text-gray-400',
    gridLine: 'border-gray-700/30',
    weekStripBg: 'bg-gray-900/80 backdrop-blur-lg',
    weekDayActive: 'bg-gradient-to-r from-purple-500 to-pink-500 text-white',
    weekDayInactive: 'bg-gray-800/60 text-gray-400',
    moodDot: 'bg-pink-400',
    nowLine: 'bg-pink-500 shadow-[0_0_10px_rgba(236,72,153,0.6)]',
    nowChipBg: 'bg-pink-500',
    nowChipText: 'text-white',
    posterFilter: 'contrast-120 saturate-150',
    posterOverlay: 'from-purple-900/80 via-pink-900/50 to-transparent',
    posterBorder: 'border-purple-500/40',
    iconCardBg: 'bg-gradient-to-br',
    iconCardText: 'text-white',
    iconCardShadow: 'shadow-lg shadow-purple-500/20',
    memoryFrame: 'ring-2 ring-pink-400/60 shadow-xl shadow-pink-500/30',
    textPrimary: 'text-white',
    textSecondary: 'text-gray-300',
    dayHeaderText: 'text-gray-300',
  },
  paper: {
    name: 'Warm Paper',
    background: 'bg-gradient-to-br from-amber-50 via-orange-50/40 to-amber-100/30',
    glassBg: 'bg-white/50',
    glassBlur: 'backdrop-blur-xl',
    glassBorder: 'border-amber-200/40',
    glassShadow: 'shadow-lg shadow-amber-500/5',
    timeRailBg: 'bg-amber-100/40 backdrop-blur-xl',
    timeRailText: 'text-amber-900',
    gridLine: 'border-amber-200/30',
    weekStripBg: 'bg-white/80 backdrop-blur-lg',
    weekDayActive: 'bg-gradient-to-r from-orange-400 to-amber-500 text-white',
    weekDayInactive: 'bg-white/60 text-amber-800',
    moodDot: 'bg-orange-400',
    nowLine: 'bg-orange-500',
    nowChipBg: 'bg-orange-500',
    nowChipText: 'text-white',
    posterFilter: 'sepia-20 contrast-105 saturate-110',
    posterOverlay: 'from-orange-900/80 via-amber-800/50 to-transparent',
    posterBorder: 'border-amber-300/40',
    iconCardBg: 'bg-gradient-to-br',
    iconCardText: 'text-white',
    iconCardShadow: 'shadow-md',
    memoryFrame: 'ring-2 ring-orange-400/60 shadow-xl shadow-orange-500/20',
    textPrimary: 'text-amber-900',
    textSecondary: 'text-amber-800',
    dayHeaderText: 'text-amber-800',
  },
};

type WeekCanvasProps = {
  theme: CalendarTheme;
  isCompact?: boolean;
};

export function WeekCanvasEditorial({ theme, isCompact = false }: WeekCanvasProps) {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const [dayPairIndex, setDayPairIndex] = useState(0);
  
  // ===== SMART TIME RANGE + ADAPTIVE HEIGHT =====
  const timeSlots = [7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]; // 07:00 - 20:00
  const HOUR_HEIGHT = isCompact ? 60 : 90; // Compact: 60px, Expanded: 90px
  const TIME_START = 7;
  const TIME_RANGE = 13; // 07:00 - 20:00 = 13 Stunden
  
  const currentHour = 14;
  const currentMinute = 3;
  const currentDay = 1; // Tuesday

  const getDayPair = (pairIndex: number) => {
    // ===== COMPACT MODE: Zeige ALLE 7 Tage =====
    if (isCompact) return [0, 1, 2, 3, 4, 5, 6];
    
    // ===== NORMAL MODE: Zeige 2 Tage mit Navigation =====
    if (pairIndex === 0) return [0, 1]; // Mon+Tue
    if (pairIndex === 1) return [2, 3]; // Wed+Thu
    if (pairIndex === 2) return [4, 5]; // Fri+Sat
    return [6]; // Sun only
  };

  const currentPair = getDayPair(dayPairIndex);
  const themeConfig = themes[theme];

  // ===== PROPORTIONALE GRÖSSE (optimiert für neue Range) =====
  const getEventStyle = (event: WeekEvent) => {
    const startPos = ((event.startHour + event.startMinute / 60 - TIME_START) / TIME_RANGE) * 100;
    const duration = (event.endHour + event.endMinute / 60) - (event.startHour + event.startMinute / 60);
    const height = (duration / TIME_RANGE) * 100;
    
    // Minimale Höhe für lesbarkeit (ca. 25 Minuten bei 90px/h)
    const minHeightPercent = 4.5;
    const actualHeight = Math.max(height, minHeightPercent);
    
    return {
      top: `${startPos}%`,
      height: `${actualHeight}%`,
      duration: duration,
    };
  };

  // ===== ALL-DAY EVENT STYLING =====
  const getAllDayEventStyle = (eventType: AllDayEvent['type']) => {
    const baseStyles = 'text-xs font-medium px-2.5 py-1 rounded-md border backdrop-blur-sm transition-all hover:scale-[1.02] cursor-pointer';
    
    const typeStyles = {
      'out-of-office': {
        daylight: 'bg-red-100/80 border-red-200/60 text-red-700',
        neon: 'bg-red-900/60 border-red-500/40 text-red-300',
        paper: 'bg-red-50/80 border-red-200/60 text-red-800',
      },
      'holiday': {
        daylight: 'bg-green-100/80 border-green-200/60 text-green-700',
        neon: 'bg-green-900/60 border-green-500/40 text-green-300',
        paper: 'bg-green-50/80 border-green-200/60 text-green-800',
      },
      'birthday': {
        daylight: 'bg-pink-100/80 border-pink-200/60 text-pink-700',
        neon: 'bg-pink-900/60 border-pink-500/40 text-pink-300',
        paper: 'bg-pink-50/80 border-pink-200/60 text-pink-800',
      },
      'multi-day': {
        daylight: 'bg-blue-100/80 border-blue-200/60 text-blue-700',
        neon: 'bg-blue-900/60 border-blue-500/40 text-blue-300',
        paper: 'bg-blue-50/80 border-blue-200/60 text-blue-800',
      },
      'todo': {
        daylight: 'bg-gray-100/80 border-gray-200/60 text-gray-700',
        neon: 'bg-gray-800/60 border-gray-600/40 text-gray-300',
        paper: 'bg-gray-50/80 border-gray-200/60 text-gray-800',
      },
    };

    return `${baseStyles} ${typeStyles[eventType][theme]}`;
  };

  return (
    <div className={`${themeConfig.background} min-h-screen transition-colors duration-300 relative overflow-hidden pb-6`}>
      {/* Grain Texture Overlay */}
      <div 
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='200' height='200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' /%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' /%3E%3C/svg%3E")`,
        }}
      />

      {/* ===== STICKY HEADER mit Day Navigation + All-Day Events ===== */}
      <div className="sticky top-0 z-30 bg-white/80 backdrop-blur-lg border-b border-gray-200/30">
        {/* Navigation + Day Headers Row */}
        <div className="px-4 py-3 flex items-center gap-3">
          {/* Navigation Left - verstecken im Compact Mode */}
          {!isCompact && (
            <button 
              onClick={() => setDayPairIndex(prev => Math.max(0, prev - 1))}
              disabled={dayPairIndex === 0}
              className={`p-1.5 rounded-full transition flex-shrink-0 ${
                dayPairIndex === 0 ? 'opacity-30 cursor-not-allowed' : 'hover:bg-white/60'
              }`}
            >
              <ChevronLeft className={`w-5 h-5 ${themeConfig.textPrimary}`} />
            </button>
          )}
          
          {/* Day Headers Structure - aligned mit unten */}
          <div className="flex items-stretch gap-3 flex-1">
            {/* Time Rail Spacer (44px wie unten) */}
            <div className="w-11 flex-shrink-0" />
            
            {/* Day Headers Grid (matched mit Columns) */}
            <div className={`flex-1 flex ${isCompact ? 'gap-2' : 'gap-2 justify-center'}`}>
              {currentPair.map((dayIndex) => {
                const isToday = dayIndex === currentDay;
                
                return (
                  <div 
                    key={dayIndex} 
                    className={`flex flex-col items-center justify-center gap-0.5 ${
                      isCompact ? 'flex-1' : ''
                    }`}
                  >
                    {/* Buchstabe ÜBER Zahl (vertikal gestapelt) */}
                    <div className={`text-[10px] font-medium ${
                      isToday ? 'text-blue-600' : themeConfig.textSecondary
                    }`}>
                      {days[dayIndex].charAt(0)}
                    </div>
                    <div className={`${
                      isCompact ? 'px-2 py-0.5 text-xs' : 'px-4 py-1.5 text-sm'
                    } rounded-full font-semibold transition ${
                      isToday ? themeConfig.weekDayActive : themeConfig.weekDayInactive
                    }`}>
                      {22 + dayIndex}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          
          {/* Navigation Right - verstecken im Compact Mode */}
          {!isCompact && (
            <button 
              onClick={() => setDayPairIndex(prev => Math.min(3, prev + 1))}
              disabled={dayPairIndex === 3}
              className={`p-1.5 rounded-full transition flex-shrink-0 ${
                dayPairIndex === 3 ? 'opacity-30 cursor-not-allowed' : 'hover:bg-white/60'
              }`}
            >
              <ChevronRight className={`w-5 h-5 ${themeConfig.textPrimary}`} />
            </button>
          )}
        </div>

        {/* All-Day Events Row */}
        <div className="px-4 pb-2 flex items-start gap-3">
          {/* Navigation Spacer Left */}
          {!isCompact && <div className="w-[34px] flex-shrink-0" />}
          
          {/* All-Day Events Structure */}
          <div className="flex items-start gap-3 flex-1">
            {/* Time Rail Spacer */}
            <div className="w-11 flex-shrink-0" />
            
            {/* All-Day Events Grid */}
            <div className={`flex-1 flex ${isCompact ? 'gap-2' : 'gap-2 justify-center'}`}>
              {currentPair.map((dayIndex) => {
                const allDayEvents = mockAllDayEvents.filter(e => e.day === dayIndex);
                
                return (
                  <div 
                    key={`allday-${dayIndex}`}
                    className={`${isCompact ? 'flex-1' : 'flex-1'} ${isCompact ? 'space-y-1' : 'space-y-1.5'}`}
                  >
                    {allDayEvents.length > 0 ? (
                      allDayEvents.map((event) => (
                        <div
                          key={event.id}
                          className={`${getAllDayEventStyle(event.type)} ${isCompact ? 'px-1.5 py-0.5' : ''}`}
                          title={event.title}
                        >
                          {isCompact ? (
                            // Compact: Nur Icon
                            <div className="flex items-center justify-center">
                              {event.type === 'out-of-office' && (
                                <svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                                </svg>
                              )}
                              {event.type === 'holiday' && (
                                <svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                                </svg>
                              )}
                              {event.type === 'todo' && (
                                <svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                                </svg>
                              )}
                              {event.type === 'birthday' && (
                                <svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 15.546c-.523 0-1.046.151-1.5.454a2.704 2.704 0 01-3 0 2.704 2.704 0 00-3 0 2.704 2.704 0 01-3 0 2.704 2.704 0 00-3 0 2.704 2.704 0 01-3 0 2.701 2.701 0 00-1.5-.454M9 6v2m3-2v2m3-2v2M9 3h.01M12 3h.01M15 3h.01M21 21v-7a2 2 0 00-2-2H5a2 2 0 00-2 2v7h18zm-3-9v-2a2 2 0 00-2-2H8a2 2 0 00-2 2v2h12z" />
                                </svg>
                              )}
                              {event.type === 'multi-day' && (
                                <svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                              )}
                            </div>
                          ) : (
                            // Normal: Icon + Text
                            <div className="flex items-center gap-1.5">
                              {event.type === 'out-of-office' && (
                                <svg className="w-3 h-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                                </svg>
                              )}
                              {event.type === 'holiday' && (
                                <svg className="w-3 h-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                                </svg>
                              )}
                              {event.type === 'todo' && (
                                <svg className="w-3 h-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                                </svg>
                              )}
                              {event.type === 'birthday' && (
                                <svg className="w-3 h-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 15.546c-.523 0-1.046.151-1.5.454a2.704 2.704 0 01-3 0 2.704 2.704 0 00-3 0 2.704 2.704 0 01-3 0 2.704 2.704 0 00-3 0 2.704 2.704 0 01-3 0 2.701 2.701 0 00-1.5-.454M9 6v2m3-2v2m3-2v2M9 3h.01M12 3h.01M15 3h.01M21 21v-7a2 2 0 00-2-2H5a2 2 0 00-2 2v7h18zm-3-9v-2a2 2 0 00-2-2H8a2 2 0 00-2 2v2h12z" />
                                </svg>
                              )}
                              {event.type === 'multi-day' && (
                                <svg className="w-3 h-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                              )}
                              <span className="line-clamp-1 flex-1 text-[10px]">{event.title}</span>
                            </div>
                          )}
                        </div>
                      ))
                    ) : (
                      // Leerer Platzhalter für Alignment
                      <div className={isCompact ? 'h-6' : 'h-8'}></div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
          
          {/* Navigation Spacer Right */}
          {!isCompact && <div className="w-[34px] flex-shrink-0" />}
        </div>
      </div>

      {/* ===== CALENDAR CANVAS (optimiert) ===== */}
      <div className="flex px-3 gap-2 mt-4">
        {/* ===== SCHMALE TIME RAIL (44px) ===== */}
        <div className={`w-11 flex-shrink-0 ${themeConfig.timeRailBg} ${themeConfig.glassBlur} rounded-[16px] border ${themeConfig.glassBorder} overflow-hidden`}>
          {/* Time Slots (direkt ohne Spacer) */}
          <div className="py-3">
            {timeSlots.map((hour) => (
              <div key={hour} style={{ height: `${HOUR_HEIGHT}px` }} className="flex items-start justify-center pt-1">
                <span className={`text-[11px] ${themeConfig.timeRailText} font-medium`}>
                  {hour.toString().padStart(2, '0')}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* ===== DAY COLUMNS (mehr Platz!) ===== */}
        <div className={`flex-1 flex gap-2 ${currentPair.length === 1 ? 'justify-center' : ''}`}>
          {currentPair.map((dayIndex, idx) => {
            const dayEvents = mockWeekEvents.filter(e => e.day === dayIndex);
            const allDayEvents = mockAllDayEvents.filter(e => e.day === dayIndex);
            const isToday = dayIndex === currentDay;
            const hasEvents = dayEvents.length > 0;
            
            return (
              <div 
                key={dayIndex} 
                className={`flex-1 ${currentPair.length === 1 ? 'max-w-md' : ''}`}
              >
                {/* ===== GLASS PANEL (nur Zeitraster - All-Day Events sind jetzt im Header!) ===== */}
                <div className={`${themeConfig.glassBg} ${themeConfig.glassBlur} ${themeConfig.glassBorder} ${themeConfig.glassShadow} rounded-[20px] overflow-hidden`}>
                  {/* ===== ZEITRASTER (Grid Container) ===== */}
                  <div className="relative" style={{ height: `${timeSlots.length * HOUR_HEIGHT}px` }}>
                    {/* Grid Lines */}
                    {timeSlots.map((hour, idx) => (
                      <div
                        key={hour}
                        className={`absolute left-0 right-0 border-t ${themeConfig.gridLine}`}
                        style={{ 
                          top: `${idx * HOUR_HEIGHT}px`,
                          height: `${HOUR_HEIGHT}px`
                        }}
                      />
                    ))}

                    {/* Now Line */}
                    {isToday && currentHour >= TIME_START && currentHour <= (TIME_START + TIME_RANGE) && (
                      <div
                        className={`absolute left-0 right-0 h-[2px] ${themeConfig.nowLine} z-20`}
                        style={{ top: `${((currentHour + currentMinute / 60 - TIME_START) / TIME_RANGE) * 100}%` }}
                      >
                        <div className={`absolute -left-1 -top-1.5 w-3 h-3 ${themeConfig.nowLine} rounded-full`}></div>
                      </div>
                    )}

                    {/* Event Stickers */}
                    {dayEvents.map((event) => {
                      const style = getEventStyle(event);
                      const isPosterCard = event.type === 'social' && event.imageUrl && !isCompact; // Im Compact: keine Bilder!
                      const isIconCard = event.type === 'personal' || isCompact; // Im Compact: alles als Icon Card
                      const isSmall = style.duration < 1;
                      
                      // Icon Mapping für Social Events (wenn Compact Mode)
                      const getSocialIcon = (title: string): string => {
                        if (title.toLowerCase().includes('run') || title.toLowerCase().includes('morning')) return 'run';
                        if (title.toLowerCase().includes('yoga')) return 'yoga';
                        if (title.toLowerCase().includes('tennis') || title.toLowerCase().includes('gym')) return 'gym';
                        if (title.toLowerCase().includes('coffee')) return 'coffee';
                        if (title.toLowerCase().includes('bar') || title.toLowerCase().includes('night')) return 'food';
                        return 'travel';
                      };
                      
                      // Color Mapping für Social Events (wenn Compact Mode)
                      const getSocialColor = (title: string): string => {
                        if (title.toLowerCase().includes('run')) return 'from-green-500 to-green-600';
                        if (title.toLowerCase().includes('yoga')) return 'from-purple-500 to-purple-600';
                        if (title.toLowerCase().includes('tennis')) return 'from-yellow-500 to-yellow-600';
                        if (title.toLowerCase().includes('coffee')) return 'from-amber-500 to-amber-600';
                        if (title.toLowerCase().includes('bar')) return 'from-pink-500 to-pink-600';
                        return 'from-teal-500 to-teal-600';
                      };
                      
                      return (
                        <div
                          key={event.id}
                          className={`absolute ${isCompact ? 'left-0.5 right-0.5' : 'left-2 right-2'} rounded-[${isCompact ? '10px' : '14px'}] overflow-hidden cursor-pointer transition-all hover:scale-[1.02] z-10 ${
                            event.isHighlight ? themeConfig.memoryFrame : ''
                          }`}
                          style={{ top: style.top, height: style.height }}
                        >
                          {isPosterCard ? (
                            // Poster Cover Card (nur Normal Mode)
                            <div className="relative h-full">
                              <img
                                src={event.imageUrl}
                                alt={event.title}
                                className={`w-full h-full object-cover ${themeConfig.posterFilter}`}
                                style={{ filter: 'contrast(1.1) saturate(0.9)' }}
                              />
                              <div className={`absolute inset-0 bg-gradient-to-t ${themeConfig.posterOverlay} mix-blend-multiply`}></div>
                              <div 
                                className="absolute inset-0 opacity-10 mix-blend-overlay"
                                style={{
                                  backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence baseFrequency='0.8' /%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' /%3E%3C/svg%3E")`,
                                }}
                              />
                              
                              <div className="absolute inset-x-0 bottom-0 p-2.5">
                                <h3 className={`text-white font-bold tracking-tight line-clamp-2 drop-shadow-md ${
                                  isSmall ? 'text-xs mb-0.5' : 'text-sm mb-1'
                                }`}>
                                  {event.title}
                                </h3>
                                
                                <div className="inline-flex items-center gap-1 px-2 py-0.5 bg-white/20 backdrop-blur-sm border border-white/30 rounded-full">
                                  <Clock className="w-3 h-3 text-white" />
                                  <span className="text-[11px] text-white font-medium">
                                    {event.startHour.toString().padStart(2, '0')}:{event.startMinute.toString().padStart(2, '0')}
                                  </span>
                                </div>
                              </div>
                            </div>
                          ) : isIconCard ? (
                            // Icon Card (Personal + Compact Mode Social)
                            <div className={`h-full ${themeConfig.iconCardBg} ${
                              event.type === 'social' ? getSocialColor(event.title) : event.color
                            } flex ${
                              isCompact ? 'p-1.5 flex-col items-center justify-center gap-1' :
                              isSmall ? 'p-2 items-center gap-2' : 'p-2.5 flex-col justify-end gap-2'
                            } ${themeConfig.iconCardShadow} relative`}>
                              
                              {isCompact ? (
                                // Compact: Icon + Titel (vertikal)
                                <>
                                  <div className="w-6 h-6 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/30 flex-shrink-0">
                                    <LifestyleIcon 
                                      type={event.type === 'social' ? getSocialIcon(event.title) : (event.icon || 'work')} 
                                      className="text-white text-xs" 
                                    />
                                  </div>
                                  <h4 className="text-white font-bold text-[8px] leading-tight text-center line-clamp-2 w-full">
                                    {event.title}
                                  </h4>
                                </>
                              ) : isSmall ? (
                                <>
                                  <div className="w-7 h-7 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center flex-shrink-0 border border-white/30">
                                    <LifestyleIcon type={event.icon || 'work'} className="text-white text-sm" />
                                  </div>
                                  
                                  <div className="flex-1 min-w-0">
                                    <h4 className={`text-xs font-bold ${themeConfig.iconCardText} line-clamp-1`}>
                                      {event.title}
                                    </h4>
                                  </div>
                                </>
                              ) : (
                                <>
                                  <div className="w-9 h-9 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/30">
                                    <LifestyleIcon type={event.icon || 'work'} className="text-white text-lg" />
                                  </div>
                                  
                                  <div className="w-full">
                                    <h4 className={`text-sm font-bold ${themeConfig.iconCardText} line-clamp-2 mb-1`}>
                                      {event.title}
                                    </h4>
                                    
                                    <div className="inline-flex items-center gap-1 px-2 py-0.5 bg-white/20 backdrop-blur-sm border border-white/30 rounded-full">
                                      <Clock className="w-3 h-3 text-white" />
                                      <span className="text-[11px] text-white font-medium">
                                        {event.startHour.toString().padStart(2, '0')}:{event.startMinute.toString().padStart(2, '0')}
                                      </span>
                                    </div>
                                  </div>
                                </>
                              )}
                            </div>
                          ) : null}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}