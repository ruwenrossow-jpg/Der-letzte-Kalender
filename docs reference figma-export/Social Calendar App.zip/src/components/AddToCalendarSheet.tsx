import { Sparkles, Dumbbell, BookOpen, Zap, ShoppingBag, Users as UsersIcon, Plane } from 'lucide-react';
import { useState } from 'react';
import { EventCard, type EventCardData } from './EventCard';

type AddMode = 'choose' | 'suggestions' | 'template';
type Template = {
  id: string;
  name: string;
  icon: typeof Dumbbell;
  emoji: string;
  color: string;
  defaultDuration: number; // in minutes
};

const templates: Template[] = [
  { id: 'workout', name: 'Workout', icon: Dumbbell, emoji: '💪', color: 'bg-gray-700', defaultDuration: 60 },
  { id: 'study', name: 'Study', icon: BookOpen, emoji: '📚', color: 'bg-gray-700', defaultDuration: 120 },
  { id: 'focus', name: 'Focus', icon: Zap, emoji: '⚡', color: 'bg-gray-700', defaultDuration: 90 },
  { id: 'errand', name: 'Errand', icon: ShoppingBag, emoji: '🛍️', color: 'bg-gray-700', defaultDuration: 30 },
  { id: 'social', name: 'Social', icon: UsersIcon, emoji: '🎉', color: 'bg-gray-700', defaultDuration: 120 },
  { id: 'travel', name: 'Travel', icon: Plane, emoji: '✈️', color: 'bg-gray-700', defaultDuration: 180 },
];

const suggestedEvents: EventCardData[] = [
  {
    id: 'sug-1',
    title: 'Coffee & Code',
    time: '14:00',
    endTime: '16:00',
    location: 'Campus Library',
    source: 'CS Department',
    imageUrl: 'https://images.unsplash.com/photo-1623121181613-eeced17aea39?w=400',
    attendees: 8,
    contextLabel: 'Fits your next gap',
    category: 'university',
  },
  {
    id: 'sug-2',
    title: 'Yoga Session',
    time: '14:30',
    endTime: '15:30',
    location: 'Wellness Center',
    source: 'Yoga Collective',
    imageUrl: 'https://images.unsplash.com/photo-1750698544932-c7471990f1ca?w=400',
    attendees: 5,
    category: 'sports',
  },
];

type AddToCalendarSheetProps = {
  onClose: () => void;
  onAdd: (item: any) => void;
};

export function AddToCalendarSheet({ onClose, onAdd }: AddToCalendarSheetProps) {
  const [mode, setMode] = useState<AddMode>('choose');
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);

  const handleTemplateSelect = (template: Template) => {
    setSelectedTemplate(template);
    // Auto-confirm after template selection (2-tap max)
    setTimeout(() => {
      onAdd({
        type: 'personal',
        template: template.id,
        name: template.name,
        emoji: template.emoji,
        color: template.color,
        duration: template.defaultDuration,
        time: '14:00', // Default to next free gap
      });
      onClose();
    }, 100);
  };

  const handleEventAdd = (eventId: string) => {
    onAdd({ type: 'event', eventId });
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-t-[32px] w-full max-w-md max-h-[80vh] overflow-y-auto shadow-2xl animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Choose Mode */}
        {mode === 'choose' && (
          <div className="p-6 space-y-6">
            <div>
              <h2>Shape your day</h2>
              <p className="text-sm text-gray-500 mt-1">Add instantly to My Flow</p>
            </div>

            {/* Primary: Add to My Flow (Suggested Events) */}
            <button
              onClick={() => setMode('suggestions')}
              className="w-full btn-power"
            >
              <Sparkles className="w-5 h-5" />
              <span className="font-medium">Add to My Flow</span>
            </button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-200"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">or</span>
              </div>
            </div>

            {/* Secondary: Add Personal Block */}
            <div>
              <p className="text-sm text-gray-700 mb-3">Add a personal block</p>
              <div className="grid grid-cols-3 gap-3">
                {templates.map((template) => {
                  const Icon = template.icon;
                  return (
                    <button
                      key={template.id}
                      onClick={() => handleTemplateSelect(template)}
                      className="flex flex-col items-center gap-2 p-4 rounded-[16px] bg-gray-50 hover:bg-gray-100 transition-all active:scale-95"
                    >
                      <div className={`w-12 h-12 ${template.color} rounded-full flex items-center justify-center text-white text-xl shadow-sm`}>
                        {template.emoji}
                      </div>
                      <span className="text-xs text-gray-700">{template.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full text-gray-400 text-sm hover:text-gray-600 transition"
            >
              Not now
            </button>
          </div>
        )}

        {/* Suggestions Mode */}
        {mode === 'suggestions' && (
          <div className="p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2>Fits Your Gap</h2>
                <p className="text-sm text-gray-500 mt-1">Starting at 14:00</p>
              </div>
              <button
                onClick={() => setMode('choose')}
                className="text-sm text-gray-500 hover:text-gray-700"
              >
                Back
              </button>
            </div>

            {suggestedEvents.map((event) => (
              <EventCard
                key={event.id}
                event={event}
                onAdd={handleEventAdd}
              />
            ))}

            <button
              onClick={onClose}
              className="w-full text-gray-400 text-sm hover:text-gray-600 transition"
            >
              Not now
            </button>
          </div>
        )}
      </div>
    </div>
  );
}