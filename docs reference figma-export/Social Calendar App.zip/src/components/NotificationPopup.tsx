import { X, Users, MapPin, Clock, Sparkles, Navigation } from 'lucide-react';
import { useState } from 'react';

type Notification = {
  id: string;
  title: string;
  source: string;
  imageUrl: string;
  time: string;
  endTime: string;
  location: string;
  friendsGoing?: number;
  contextLabel?: string;
  distance?: string;
};

type NotificationPopupProps = {
  onClose: () => void;
  onNotificationHandled: (id: string, added: boolean) => void;
};

const mockNotifications: Notification[] = [
  {
    id: 'notif-1',
    title: 'Sunset 10k Run',
    source: 'Running Group',
    imageUrl: 'https://images.unsplash.com/photo-1699959560616-aa17ace76879?w=800',
    time: '18:00',
    endTime: '19:30',
    location: 'Central Park',
    friendsGoing: 3,
    contextLabel: 'Fits your 6 PM gap',
    distance: '12 min walk',
  },
];

export function NotificationPopup({ onClose, onNotificationHandled }: NotificationPopupProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAdding, setIsAdding] = useState(false);

  const currentNotif = mockNotifications[currentIndex];

  if (!currentNotif) {
    onClose();
    return null;
  }

  const handleAdd = () => {
    setIsAdding(true);
    setTimeout(() => {
      onNotificationHandled(currentNotif.id, true);
      if (currentIndex < mockNotifications.length - 1) {
        setCurrentIndex(currentIndex + 1);
        setIsAdding(false);
      } else {
        onClose();
      }
    }, 600);
  };

  const handleDismiss = () => {
    onNotificationHandled(currentNotif.id, false);
    if (currentIndex < mockNotifications.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 backdrop-blur-sm">
      <div className={`bg-white rounded-t-[32px] w-full max-w-md max-h-[80vh] overflow-y-auto shadow-2xl animate-slide-up ${
        isAdding ? 'animate-fly-to-calendar' : ''
      }`}>
        {/* Header */}
        <div className="sticky top-0 bg-white/80 backdrop-blur-lg px-6 pt-6 pb-4 border-b border-gray-100 rounded-t-[32px]">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h2 className="text-xl">Your crew is going</h2>
              <p className="text-sm text-gray-500">New plan from {currentNotif.source}</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition"
            >
              <X className="w-5 h-5 text-gray-700" />
            </button>
          </div>
        </div>

        {/* Event Preview */}
        <div className="p-6 space-y-4">
          {/* Social Proof */}
          {currentNotif.friendsGoing && (
            <div className="chip-social inline-flex">
              <Users className="w-3 h-3" />
              <span>{currentNotif.friendsGoing} friends going</span>
            </div>
          )}

          {/* Image */}
          <div className="relative aspect-[16/10] rounded-[20px] overflow-hidden">
            <img
              src={currentNotif.imageUrl}
              alt={currentNotif.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <h3 className="text-white text-2xl mb-2">{currentNotif.title}</h3>
            </div>
          </div>

          {/* Details */}
          <div className="space-y-3">
            <div className="flex items-center gap-3 text-gray-700">
              <Clock className="w-5 h-5 text-gray-500" />
              <span>{currentNotif.time} - {currentNotif.endTime}</span>
            </div>

            <div className="flex items-center gap-3 text-gray-700">
              <MapPin className="w-5 h-5 text-gray-500" />
              <span>{currentNotif.location}</span>
            </div>

            {currentNotif.distance && (
              <div className="flex items-center gap-3 text-gray-600">
                <Navigation className="w-5 h-5 text-gray-500" />
                <span>{currentNotif.distance}</span>
              </div>
            )}

            {currentNotif.contextLabel && (
              <div className="chip-context inline-flex">
                <span>{currentNotif.contextLabel}</span>
              </div>
            )}
          </div>

          {/* Primary Action */}
          <button
            onClick={handleAdd}
            disabled={isAdding}
            className="w-full btn-power mt-6"
          >
            <Sparkles className="w-5 h-5" />
            <span className="font-medium">Add to My Flow</span>
          </button>

          {/* Secondary Actions */}
          <div className="flex flex-col gap-2 text-center">
            <button
              onClick={handleDismiss}
              className="w-full text-gray-500 text-sm hover:text-gray-700 transition py-2"
            >
              Not now
            </button>
            <div className="flex items-center justify-center gap-4 text-xs text-gray-400">
              <button className="hover:text-gray-600 transition">Mute this crew</button>
              <span>·</span>
              <button className="hover:text-gray-600 transition">Hide this type</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}