import { X, Navigation, Users, Send, Sparkles, Check } from 'lucide-react';
import { useState } from 'react';

export type EventDetail = {
  id: string;
  title: string;
  imageUrl?: string; // Only for social/highlight events
  time: string;
  endTime?: string;
  location: string;
  source: string;
  attendees?: number;
  friendsGoing?: number;
  distance?: string;
  description?: string;
  category?: 'university' | 'sports' | 'nightlife' | 'personal';
  type?: 'social' | 'personal';
  icon?: string; // For personal blocks
  color?: string; // For personal blocks
};

type EventDetailModalProps = {
  event: EventDetail;
  onClose: () => void;
  onAddToFlow: (eventId: string) => void;
  isAdded?: boolean;
};

export function EventDetailModal({ event, onClose, onAddToFlow, isAdded = false }: EventDetailModalProps) {
  const [added, setAdded] = useState(isAdded);
  const [isAnimating, setIsAnimating] = useState(false);

  const handleAddClick = () => {
    if (added) return;
    
    setIsAnimating(true);
    setAdded(true);
    onAddToFlow(event.id);
    
    setTimeout(() => {
      setIsAnimating(false);
      onClose();
    }, 600);
  };

  const timeRange = event.endTime 
    ? `${event.time} - ${event.endTime}` 
    : event.time;

  const isSocialEvent = event.type === 'social' || event.imageUrl;
  const isPersonalBlock = event.type === 'personal' && !event.imageUrl;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className={`bg-white rounded-t-[32px] w-full max-w-md max-h-[85vh] overflow-y-auto shadow-2xl animate-slide-up ${
          isAnimating ? 'animate-fly-to-calendar' : ''
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 bg-white/90 backdrop-blur-sm rounded-full shadow-md hover:bg-white transition z-10"
        >
          <X className="w-5 h-5 text-gray-700" />
        </button>

        {/* Hero Image or Icon Header */}
        {isSocialEvent && event.imageUrl ? (
          // Social Event with Photo
          <div className="relative h-[240px] rounded-t-[32px] overflow-hidden">
            <img
              src={event.imageUrl}
              alt={event.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent"></div>
            
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <div className="chip-source mb-2">{event.source}</div>
              <h2 className="text-white text-2xl mb-1">{event.title}</h2>
              {event.friendsGoing && (
                <div className="inline-flex items-center gap-1.5 px-2 py-1 bg-white/20 backdrop-blur-sm border border-white/30 rounded-full">
                  <Users className="w-3 h-3 text-white" />
                  <span className="text-xs text-white">{event.friendsGoing} friends going</span>
                </div>
              )}
            </div>
          </div>
        ) : isPersonalBlock ? (
          // Personal Block with Icon
          <div className="pt-6 px-6 pb-4">
            <div className="flex items-center gap-4 mb-4">
              <div className={`w-16 h-16 ${event.color || 'bg-gray-700'} rounded-full flex items-center justify-center text-white text-2xl shadow-md`}>
                {event.icon || '📅'}
              </div>
              <div className="flex-1">
                <div className="chip-source mb-1">{event.source}</div>
                <h2 className="text-gray-900">{event.title}</h2>
              </div>
            </div>
          </div>
        ) : null}

        {/* Content */}
        <div className="px-6 pb-6 space-y-6">
          {/* Quick Info */}
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center flex-shrink-0">
                <svg className="w-5 h-5 text-blue-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="10" />
                  <path d="M12 6v6l4 2" />
                </svg>
              </div>
              <div className="flex-1 pt-1.5">
                <p className="text-sm text-gray-500 mb-0.5">Time</p>
                <p className="text-gray-900">{timeRange}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-green-50 rounded-full flex items-center justify-center flex-shrink-0">
                <Navigation className="w-5 h-5 text-green-600" />
              </div>
              <div className="flex-1 pt-1.5">
                <p className="text-sm text-gray-500 mb-0.5">Location</p>
                <p className="text-gray-900">{event.location}</p>
                {event.distance && (
                  <p className="text-xs text-green-600 mt-0.5">{event.distance}</p>
                )}
              </div>
            </div>

            {event.attendees && (
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-purple-50 rounded-full flex items-center justify-center flex-shrink-0">
                  <Users className="w-5 h-5 text-purple-600" />
                </div>
                <div className="flex-1 pt-1.5">
                  <p className="text-sm text-gray-500 mb-0.5">Attendees</p>
                  <p className="text-gray-900">{event.attendees} going</p>
                </div>
              </div>
            )}
          </div>

          {/* Description */}
          {event.description && (
            <div>
              <p className="text-sm text-gray-500 mb-2">About</p>
              <p className="text-gray-700 text-sm leading-relaxed">{event.description}</p>
            </div>
          )}

          {/* Quick Actions (Icon Row) */}
          <div className="flex items-center gap-3">
            <button className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-gray-100 rounded-[16px] hover:bg-gray-200 transition-all active:scale-95">
              <Navigation className="w-4 h-4 text-gray-700" />
              <span className="text-sm text-gray-900">Route</span>
            </button>
            
            <button className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-gray-100 rounded-[16px] hover:bg-gray-200 transition-all active:scale-95">
              <Users className="w-4 h-4 text-gray-700" />
              <span className="text-sm text-gray-900">Crew</span>
            </button>
            
            <button className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-gray-100 rounded-[16px] hover:bg-gray-200 transition-all active:scale-95">
              <Send className="w-4 h-4 text-gray-700" />
              <span className="text-sm text-gray-900">Invite</span>
            </button>
          </div>

          {/* Primary CTA: Add to My Flow (Power Button) */}
          <button
            onClick={handleAddClick}
            disabled={added}
            className={`w-full btn-power ${added ? 'success' : 'animate-pulse-power'}`}
          >
            {added ? (
              <>
                <Check className="w-5 h-5" />
                <span className="font-medium">Added to My Flow ✓</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                <span className="font-medium">Add to My Flow</span>
              </>
            )}
          </button>

          {/* Secondary: Not now */}
          <button
            onClick={onClose}
            className="w-full text-gray-400 text-sm hover:text-gray-600 transition"
          >
            Not now
          </button>
        </div>
      </div>
    </div>
  );
}
