import { Users, UserCheck, Mail, Activity } from 'lucide-react';
import { useState } from 'react';
import { EventCard, type EventCardData } from './EventCard';

type FilterType = 'all' | 'friends' | 'crews' | 'professors';

const mockActiveNow = [
  { id: 'a1', name: 'Max', initials: 'MK', status: 'At Central Park' },
  { id: 'a2', name: 'Julia', initials: 'JS', status: 'Running' },
  { id: 'a3', name: 'Alex', initials: 'AL', status: 'At Library' },
];

const mockInvites: EventCardData[] = [
  {
    id: 'inv-1',
    title: 'Study Group Session',
    time: 'Tomorrow, 14:00',
    endTime: '16:00',
    location: 'Library',
    source: 'Max Klein',
    imageUrl: 'https://images.unsplash.com/photo-1722248540590-ba8b7af1d7b2?w=800',
    friendsGoing: 2,
    contextLabel: 'Invited by friend',
    category: 'university',
  },
];

const mockCrewEvents: EventCardData[] = [
  {
    id: 'crew-1',
    title: 'Sunset 10k Run',
    time: 'Today, 18:00',
    endTime: '19:30',
    location: 'Central Park',
    source: 'Running Group',
    imageUrl: 'https://images.unsplash.com/photo-1699959560616-aa17ace76879?w=800',
    friendsGoing: 3,
    distance: '12 min walk',
    category: 'sports',
  },
  {
    id: 'crew-2',
    title: 'Downtown Bar Crawl',
    time: 'Fri, 20:00',
    endTime: '23:00',
    location: 'City Center',
    source: 'Party Crew',
    imageUrl: 'https://images.unsplash.com/photo-1759870075384-4e82adc2f679?w=800',
    friendsGoing: 5,
    contextLabel: 'Trending',
    category: 'nightlife',
  },
];

export function SocialHub() {
  const [selectedFilter, setSelectedFilter] = useState<FilterType>('all');
  const [selectedEvent, setSelectedEvent] = useState<EventCardData | null>(null);

  const handleAddToFlow = (eventId: string) => {
    console.log('Adding event to flow:', eventId);
    setSelectedEvent(null);
  };

  return (
    <div className="min-h-screen bg-white pb-6">
      {/* Header */}
      <header className="sticky top-0 bg-white/80 backdrop-blur-lg z-10 px-6 pt-6 pb-4 border-b border-gray-100">
        <h1>Network</h1>
        <p className="text-sm text-gray-500 mt-1">Your social circle & activity</p>

        {/* Filter Chips */}
        <div className="flex items-center gap-2 mt-4 overflow-x-auto scrollbar-hide">
          <button
            onClick={() => setSelectedFilter('all')}
            className={`px-4 py-2 rounded-full text-sm whitespace-nowrap transition-all ${
              selectedFilter === 'all'
                ? 'bg-blue-500 text-white shadow-md'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setSelectedFilter('friends')}
            className={`px-4 py-2 rounded-full text-sm whitespace-nowrap transition-all ${
              selectedFilter === 'friends'
                ? 'bg-blue-500 text-white shadow-md'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Friends
          </button>
          <button
            onClick={() => setSelectedFilter('crews')}
            className={`px-4 py-2 rounded-full text-sm whitespace-nowrap transition-all ${
              selectedFilter === 'crews'
                ? 'bg-blue-500 text-white shadow-md'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Crews
          </button>
          <button
            onClick={() => setSelectedFilter('professors')}
            className={`px-4 py-2 rounded-full text-sm whitespace-nowrap transition-all ${
              selectedFilter === 'professors'
                ? 'bg-blue-500 text-white shadow-md'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Professors
          </button>
        </div>
      </header>

      {/* Content */}
      <div className="space-y-6 py-6">
        {/* Active Now */}
        <div>
          <div className="px-6 mb-3 flex items-center gap-2">
            <Activity className="w-5 h-5 text-green-500" />
            <h2 className="text-lg">Active Now</h2>
          </div>
          <div className="px-6">
            <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
              {mockActiveNow.map((person) => (
                <div key={person.id} className="flex-shrink-0 text-center">
                  <div className="relative mb-2">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center text-white">
                      {person.initials}
                    </div>
                    <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 rounded-full border-2 border-white"></div>
                  </div>
                  <p className="text-xs text-gray-900">{person.name}</p>
                  <p className="text-xs text-gray-500">{person.status}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Invites & Plans */}
        {mockInvites.length > 0 && (
          <div>
            <div className="px-6 mb-3 flex items-center gap-2">
              <Mail className="w-5 h-5 text-blue-500" />
              <h2 className="text-lg">Invites & Plans</h2>
            </div>
            <div className="px-6 space-y-3">
              {mockInvites.map((invite) => (
                <EventCard
                  key={invite.id}
                  event={invite}
                  onAdd={handleAddToFlow}
                  onClick={setSelectedEvent}
                  variant="compact"
                />
              ))}
            </div>
          </div>
        )}

        {/* From Your Crews */}
        <div>
          <div className="px-6 mb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-purple-500" />
              <h2 className="text-lg">From Your Crews</h2>
            </div>
            <button className="text-sm text-blue-600 hover:text-blue-700">See all</button>
          </div>
          <div className="px-6 space-y-3">
            {mockCrewEvents.map((event) => (
              <EventCard
                key={event.id}
                event={event}
                onAdd={handleAddToFlow}
                onClick={setSelectedEvent}
                variant="compact"
              />
            ))}
          </div>
        </div>
      </div>

      {/* Event Detail Bottom Sheet */}
      {selectedEvent && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 backdrop-blur-sm"
          onClick={() => setSelectedEvent(null)}
        >
          <div
            className="bg-white rounded-t-[24px] w-full max-w-md max-h-[70vh] overflow-y-auto shadow-2xl animate-slide-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 space-y-4">
              <EventCard
                event={selectedEvent}
                onAdd={handleAddToFlow}
              />
              <button
                onClick={() => setSelectedEvent(null)}
                className="w-full text-gray-400 text-sm hover:text-gray-600 transition"
              >
                Not now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
