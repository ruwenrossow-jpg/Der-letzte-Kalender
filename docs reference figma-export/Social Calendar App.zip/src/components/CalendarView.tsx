import { ChevronLeft, ChevronRight, Clock, MapPin, Sparkles, Calendar, Palette } from 'lucide-react';
import { useState } from 'react';
import { EventCard, type EventCardData } from './EventCard';
import { AddToCalendarSheet } from './AddToCalendarSheet';
import { WeekCanvasEditorial } from './CalendarWeekEditorial';
import { MonthCanvasEditorial } from './CalendarMonthEditorial';

type ViewMode = 'day' | 'week' | 'month';
type CalendarTheme = 'daylight' | 'neon' | 'paper';

// ===== LIFESTYLE ICONS =====
const LifestyleIcon = ({ type, className }: { type: string; className?: string }) => {
  const iconMap: Record<string, string> = {
    work: '✦',
    study: '◆',
    focus: '◈',
    meeting: '◉',
    gym: '◊',
    yoga: '✧',
    run: '◈',
    coffee: '◐',
    food: '◑',
    shopping: '◒',
    travel: '◓',
  };

  return (
    <div className={className}>
      {iconMap[type] || '◆'}
    </div>
  );
};

type WeekEvent = {
  id: string;
  title: string;
  day: number; // 0-6 for Mon-Sun
  startHour: number;
  startMinute: number;
  endHour: number;
  endMinute: number;
  imageUrl?: string;
  location: string;
  type: 'social' | 'personal';
  icon?: string;
  color?: string;
  isHighlight?: boolean; // For 1-2 special events per day
};

const mockWeekEvents: WeekEvent[] = [
  // Monday
  { id: 'w1', title: 'Morning Run', day: 0, startHour: 7, startMinute: 0, endHour: 8, endMinute: 0, imageUrl: 'https://images.unsplash.com/photo-1699959560616-aa17ace76879?w=400', location: 'Park', type: 'social', isHighlight: true },
  { id: 'w2', title: 'Deep Work', day: 0, startHour: 10, startMinute: 0, endHour: 12, endMinute: 0, icon: '⚡', color: 'blue', location: 'Office', type: 'personal' },
  { id: 'w3', title: 'Tennis Match', day: 0, startHour: 16, startMinute: 0, endHour: 17, endMinute: 30, imageUrl: 'https://images.unsplash.com/photo-1494251202008-582bbc3eac69?w=400', location: 'Court', type: 'social' },
  
  // Tuesday
  { id: 'w4', title: 'Yoga Flow', day: 1, startHour: 8, startMinute: 30, endHour: 9, endMinute: 30, imageUrl: 'https://images.unsplash.com/photo-1750698544932-c7471990f1ca?w=400', location: 'Studio', type: 'social', isHighlight: true },
  { id: 'w5', title: 'Study Session', day: 1, startHour: 14, startMinute: 0, endHour: 16, endMinute: 0, icon: '📚', color: 'purple', location: 'Library', type: 'personal' },
  { id: 'w6', title: 'Team Meeting', day: 1, startHour: 17, startMinute: 0, endHour: 18, endMinute: 0, icon: '💼', color: 'gray', location: 'Zoom', type: 'personal' },
  
  // Wednesday
  { id: 'w7', title: 'Coffee & Code', day: 2, startHour: 14, startMinute: 0, endHour: 16, endMinute: 0, imageUrl: 'https://images.unsplash.com/photo-1623121181613-eeced17aea39?w=400', location: 'Cafe', type: 'social' },
  
  // Friday
  { id: 'w8', title: 'Bar Night', day: 4, startHour: 20, startMinute: 0, endHour: 23, endMinute: 0, imageUrl: 'https://images.unsplash.com/photo-1759870075384-4e82adc2f679?w=400', location: 'Downtown', type: 'social' },
];

const themes = {
  daylight: {
    name: 'Daylight Editorial',
    // Layer 1: Mood Background
    background: 'bg-gradient-to-br from-gray-50 via-blue-50/30 to-green-50/20',
    grain: true,
    // Layer 2: Glass Panels
    glassBg: 'bg-white/60',
    glassBlur: 'backdrop-blur-xl',
    glassBorder: 'border border-white/40',
    glassShadow: 'shadow-lg shadow-blue-500/5',
    timeRailBg: 'bg-white/40',
    timeRailText: 'text-gray-600',
    gridLine: 'border-gray-200/30',
    // Week Strip
    weekStripBg: 'bg-white/80',
    weekDayActive: 'bg-blue-500 text-white',
    weekDayInactive: 'bg-gray-100 text-gray-600',
    moodDot: 'bg-green-400',
    // Now Line
    nowLine: 'bg-blue-500',
    nowChipBg: 'bg-blue-500',
    nowChipText: 'text-white',
    // Event Styling
    posterOverlay: 'from-blue-900/80 via-blue-800/60 to-transparent',
    posterBorder: 'border-blue-200/40',
    iconCardBg: 'bg-blue-50/80',
    iconCardBorder: 'border-blue-200/60',
    iconCardText: 'text-blue-900',
    memoryFrameBorder: 'border-2 border-blue-400/60 shadow-lg shadow-blue-500/20',
    // General text
    textPrimary: 'text-gray-900',
    textSecondary: 'text-gray-600',
    textMuted: 'text-gray-400',
  },
  neon: {
    name: 'Neon Night',
    background: 'bg-gradient-to-br from-gray-950 via-purple-950/30 to-pink-950/20',
    grain: true,
    glassBg: 'bg-gray-900/60',
    glassBlur: 'backdrop-blur-xl',
    glassBorder: 'border border-purple-500/20',
    glassShadow: 'shadow-lg shadow-purple-500/10',
    timeRailBg: 'bg-gray-950/40',
    timeRailText: 'text-gray-400',
    gridLine: 'border-gray-700/30',
    weekStripBg: 'bg-gray-900/80',
    weekDayActive: 'bg-gradient-to-r from-purple-500 to-pink-500 text-white',
    weekDayInactive: 'bg-gray-800 text-gray-400',
    moodDot: 'bg-pink-400',
    nowLine: 'bg-pink-500 shadow-[0_0_10px_rgba(236,72,153,0.6)]',
    nowChipBg: 'bg-pink-500',
    nowChipText: 'text-white',
    posterOverlay: 'from-purple-900/80 via-pink-900/60 to-transparent',
    posterBorder: 'border-purple-500/40',
    iconCardBg: 'bg-purple-900/40',
    iconCardBorder: 'border-purple-500/60',
    iconCardText: 'text-purple-100',
    memoryFrameBorder: 'border-2 border-pink-400/60 shadow-lg shadow-pink-500/30',
    textPrimary: 'text-white',
    textSecondary: 'text-gray-300',
    textMuted: 'text-gray-500',
  },
  paper: {
    name: 'Warm Paper',
    background: 'bg-gradient-to-br from-amber-50 via-orange-50/40 to-amber-100/30',
    grain: true,
    glassBg: 'bg-white/50',
    glassBlur: 'backdrop-blur-xl',
    glassBorder: 'border border-amber-200/40',
    glassShadow: 'shadow-lg shadow-amber-500/5',
    timeRailBg: 'bg-amber-100/40',
    timeRailText: 'text-amber-900',
    gridLine: 'border-amber-200/30',
    weekStripBg: 'bg-white/80',
    weekDayActive: 'bg-gradient-to-r from-orange-400 to-amber-500 text-white',
    weekDayInactive: 'bg-amber-100 text-amber-800',
    moodDot: 'bg-orange-400',
    nowLine: 'bg-orange-500',
    nowChipBg: 'bg-orange-500',
    nowChipText: 'text-white',
    posterOverlay: 'from-orange-900/80 via-amber-800/60 to-transparent',
    posterBorder: 'border-amber-300/40',
    iconCardBg: 'bg-orange-50/80',
    iconCardBorder: 'border-orange-300/60',
    iconCardText: 'text-orange-900',
    memoryFrameBorder: 'border-2 border-orange-400/60 shadow-lg shadow-orange-500/20',
    textPrimary: 'text-amber-900',
    textSecondary: 'text-amber-800',
    textMuted: 'text-amber-600',
  },
};

const gapSuggestions: EventCardData[] = [
  {
    id: 'sug-1',
    title: 'Coffee Meetup',
    time: '09:00',
    endTime: '10:00',
    location: 'Café',
    source: 'Friends',
    imageUrl: 'https://images.unsplash.com/photo-1623121181613-eeced17aea39?w=400',
    friendsGoing: 2,
    category: 'personal',
  },
];

function DayView() {
  const [currentDayIndex, setCurrentDayIndex] = useState(1); // Tue = 1
  const [isCompact, setIsCompact] = useState(false); // Toggle for compact view
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const currentTime = new Date();
  const currentHour = 14;
  const currentMinute = 3;

  // ===== TODAY'S JOURNEY (Mock Data) =====
  const todayEvents = [
    {
      id: '1',
      type: 'social' as const,
      title: 'Morning Run',
      startHour: 7,
      startMinute: 0,
      endHour: 8,
      endMinute: 0,
      location: 'Central Park',
      imageUrl: 'https://images.unsplash.com/photo-1699959560616-aa17ace76879?w=800',
    },
    {
      id: '2',
      type: 'personal' as const,
      title: 'Deep Work',
      startHour: 10,
      startMinute: 0,
      endHour: 12,
      endMinute: 0,
      location: 'Office',
      icon: 'work',
      color: 'from-blue-500 to-blue-600',
    },
    {
      id: '3',
      type: 'personal' as const,
      title: 'Study Session',
      startHour: 14,
      startMinute: 0,
      endHour: 16,
      endMinute: 0,
      location: 'Library',
      icon: 'study',
      color: 'from-purple-500 to-purple-600',
    },
    {
      id: '4',
      type: 'social' as const,
      title: 'Tennis Match',
      startHour: 18,
      startMinute: 0,
      endHour: 19,
      endMinute: 30,
      location: 'Sports Club',
      imageUrl: 'https://images.unsplash.com/photo-1494251202008-582bbc3eac69?w=800',
    },
    {
      id: '5',
      type: 'social' as const,
      title: 'Bar Night',
      startHour: 20,
      startMinute: 30,
      endHour: 23,
      endMinute: 0,
      location: 'Downtown',
      imageUrl: 'https://images.unsplash.com/photo-1759870075384-4e82adc2f679?w=800',
    },
  ];

  // ===== ALL-DAY EVENTS =====
  const allDayEvents = [
    { id: 'ad1', title: 'Christmas 🎄', type: 'holiday' as const },
    { id: 'ad2', title: 'Submit report', type: 'todo' as const },
  ];

  // ===== ALL-DAY EVENT STYLING =====
  const getAllDayEventStyle = (eventType: 'out-of-office' | 'holiday' | 'birthday' | 'multi-day' | 'todo') => {
    const typeStyles = {
      'out-of-office': 'bg-red-100/90 border-red-200/60 text-red-700',
      'holiday': 'bg-green-100/90 border-green-200/60 text-green-700',
      'birthday': 'bg-pink-100/90 border-pink-200/60 text-pink-700',
      'multi-day': 'bg-blue-100/90 border-blue-200/60 text-blue-700',
      'todo': 'bg-gray-100/90 border-gray-200/60 text-gray-700',
    };

    return `text-xs font-medium px-3 py-1.5 rounded-lg border backdrop-blur-sm ${typeStyles[eventType]}`;
  };

  // ===== HELPER: Calculate time gap between events =====
  const calculateGap = (prevEnd: number, nextStart: number) => {
    const gapMinutes = (nextStart - prevEnd) * 60;
    const hours = Math.floor(gapMinutes / 60);
    const minutes = gapMinutes % 60;
    
    if (hours === 0) return `${minutes}m free`;
    if (minutes === 0) return `${hours}h free`;
    return `${hours}h ${minutes}m free`;
  };

  // ===== HELPER: Check if event is current =====
  const isCurrentEvent = (event: typeof todayEvents[0]) => {
    const now = currentHour + currentMinute / 60;
    const eventStart = event.startHour + event.startMinute / 60;
    const eventEnd = event.endHour + event.endMinute / 60;
    return now >= eventStart && now < eventEnd;
  };

  return (
    <div className="relative bg-gradient-to-br from-gray-50 via-blue-50/20 to-white min-h-screen pb-24">
      {/* ===== NAVIGATION HEADER (wie Weekly) ===== */}
      <div className="sticky top-0 z-30 px-4 py-3 bg-white/80 backdrop-blur-lg border-b border-gray-200/30">
        <div className="flex items-center justify-between max-w-md mx-auto">
          {/* Left Arrow */}
          <button 
            onClick={() => setCurrentDayIndex(prev => Math.max(0, prev - 1))}
            disabled={currentDayIndex === 0}
            className={`p-2 rounded-full transition ${
              currentDayIndex === 0 ? 'opacity-30 cursor-not-allowed' : 'hover:bg-white/60'
            }`}
          >
            <ChevronLeft className="w-5 h-5 text-gray-900" />
          </button>
          
          {/* Center: Today + Date */}
          <div className="text-center">
            <div className="flex items-center gap-2 justify-center">
              <h3 className="text-gray-900">Today · {days[currentDayIndex]}</h3>
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
            </div>
            <p className="text-xs text-gray-500 mt-0.5">{22 + currentDayIndex} Dec · Now {currentHour.toString().padStart(2, '0')}:{currentMinute.toString().padStart(2, '0')}</p>
          </div>
          
          {/* Right: Toggle + Arrow */}
          <div className="flex items-center gap-1">
            {/* Compact Toggle */}
            <button
              onClick={() => setIsCompact(!isCompact)}
              className="p-2 rounded-full hover:bg-white/60 transition"
              title={isCompact ? 'Expand view' : 'Compact view'}
            >
              {isCompact ? (
                <svg className="w-5 h-5 text-gray-900" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l5-5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
                </svg>
              ) : (
                <svg className="w-5 h-5 text-gray-900" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8h16M4 16h16" />
                </svg>
              )}
            </button>

            {/* Right Arrow */}
            <button 
              onClick={() => setCurrentDayIndex(prev => Math.min(6, prev + 1))}
              disabled={currentDayIndex === 6}
              className={`p-2 rounded-full transition ${
                currentDayIndex === 6 ? 'opacity-30 cursor-not-allowed' : 'hover:bg-white/60'
              }`}
            >
              <ChevronRight className="w-5 h-5 text-gray-900" />
            </button>
          </div>
        </div>
      </div>

      {/* ===== JOURNEY TIMELINE ===== */}
      <div className="px-6 pt-6 max-w-md mx-auto">
        {/* ===== ALL-DAY EVENTS SECTION ===== */}
        {allDayEvents.length > 0 && (
          <div className="mb-6 space-y-2">
            {allDayEvents.map((event) => (
              <div
                key={event.id}
                className={getAllDayEventStyle(event.type)}
              >
                <div className="flex items-center gap-2">
                  {/* Icon basierend auf Type */}
                  {event.type === 'out-of-office' && (
                    <svg className="w-3.5 h-3.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                    </svg>
                  )}
                  {event.type === 'holiday' && (
                    <svg className="w-3.5 h-3.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                    </svg>
                  )}
                  {event.type === 'todo' && (
                    <svg className="w-3.5 h-3.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                  )}
                  
                  <span className="flex-1">{event.title}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {todayEvents.length === 0 ? (
          // Empty State
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <Calendar className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-600">No plans today</p>
            <p className="text-sm text-gray-400 mt-1">Tap + to start your journey</p>
          </div>
        ) : (
          <div className="relative">
            {todayEvents.map((event, index) => {
              const isCurrent = isCurrentEvent(event);
              const prevEvent = index > 0 ? todayEvents[index - 1] : null;
              const gap = prevEvent ? calculateGap(
                prevEvent.endHour + prevEvent.endMinute / 60,
                event.startHour + event.startMinute / 60
              ) : null;

              return (
                <div key={event.id} className="relative">
                  {/* ===== GAP INDICATOR (zwischen Events) ===== */}
                  {gap && (
                    <div className={`flex items-center gap-3 ${isCompact ? 'py-2' : 'py-3'} pl-6`}>
                      {/* Vertical Line */}
                      <div className="absolute left-[19px] top-0 bottom-0 w-[2px] bg-gradient-to-b from-gray-300 via-gray-200 to-gray-300"></div>
                      
                      {/* Gap Chip */}
                      <div className="relative z-10 ml-10 px-3 py-1 bg-gray-100 border border-gray-200 rounded-full">
                        <p className="text-xs text-gray-500">{gap}</p>
                      </div>
                    </div>
                  )}

                  {/* ===== EVENT CARD ===== */}
                  <div className="relative flex gap-4">
                    {/* Left: Time Badge + Connector Line */}
                    <div className="flex flex-col items-center w-10 flex-shrink-0 pt-1">
                      {/* Time Badge */}
                      <div className={`px-2 py-1 rounded-full text-[11px] font-semibold transition-all ${
                        isCurrent 
                          ? 'bg-blue-500 text-white shadow-sm' 
                          : 'bg-white border border-gray-200 text-gray-600'
                      }`}>
                        {event.startHour.toString().padStart(2, '0')}:{event.startMinute.toString().padStart(2, '0')}
                      </div>
                      
                      {/* Vertical Connector Line */}
                      {index < todayEvents.length - 1 && (
                        <div className="flex-1 w-[2px] bg-gradient-to-b from-gray-300 via-gray-200 to-transparent mt-2"></div>
                      )}
                    </div>

                    {/* Right: Event Card */}
                    <div className={`flex-1 ${isCompact ? 'pb-2' : 'pb-4'}`}>
                      {isCompact ? (
                        // ===== COMPACT VIEW =====
                        <div 
                          className={`rounded-[16px] overflow-hidden shadow-sm cursor-pointer hover:shadow-md transition-all ${
                            event.type === 'social' 
                              ? 'bg-gradient-to-r from-blue-500 to-blue-600' 
                              : `bg-gradient-to-r ${event.color}`
                          } p-3 flex items-center gap-3`}
                        >
                          {/* Icon/Indicator */}
                          <div className="w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/30 flex-shrink-0">
                            {event.type === 'social' ? (
                              <div className="w-3 h-3 bg-white rounded-full"></div>
                            ) : (
                              <LifestyleIcon type={event.icon || 'work'} className="text-white text-sm" />
                            )}
                          </div>
                          
                          {/* Content */}
                          <div className="flex-1 min-w-0">
                            <h4 className="text-white text-sm font-bold line-clamp-1">{event.title}</h4>
                            <p className="text-white/80 text-xs mt-0.5">
                              {event.startHour.toString().padStart(2, '0')}:{event.startMinute.toString().padStart(2, '0')} – {event.endHour.toString().padStart(2, '0')}:{event.endMinute.toString().padStart(2, '0')} · {event.location}
                            </p>
                          </div>

                          {/* Current Badge */}
                          {isCurrent && (
                            <div className="px-2 py-0.5 bg-white/30 backdrop-blur-sm rounded-full border border-white/40 flex-shrink-0">
                              <p className="text-[10px] text-white font-medium">Now</p>
                            </div>
                          )}
                        </div>
                      ) : event.type === 'social' ? (
                        // ===== EXPANDED: SOCIAL EVENT (Poster Card) =====
                        <div className="relative rounded-[20px] overflow-hidden shadow-md cursor-pointer hover:shadow-xl transition-all">
                          <div className="relative h-[180px]">
                            <img 
                              src={event.imageUrl} 
                              alt={event.title} 
                              className="w-full h-full object-cover"
                              style={{ filter: 'contrast(1.1) saturate(0.9)' }}
                            />
                            {/* Gradient Overlay */}
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
                            
                            {/* Content */}
                            <div className="absolute bottom-0 left-0 right-0 p-4">
                              <h3 className="text-white font-bold tracking-tight mb-2">{event.title}</h3>
                              
                              <div className="flex items-center gap-4 text-white/90 text-sm">
                                <div className="flex items-center gap-1.5">
                                  <Clock className="w-3.5 h-3.5" />
                                  <span>{event.startHour.toString().padStart(2, '0')}:{event.startMinute.toString().padStart(2, '0')} – {event.endHour.toString().padStart(2, '0')}:{event.endMinute.toString().padStart(2, '0')}</span>
                                </div>
                              </div>
                              
                              <div className="flex items-center gap-1.5 text-white/80 text-xs mt-1">
                                <MapPin className="w-3 h-3" />
                                <span>{event.location}</span>
                              </div>
                            </div>

                            {/* Current Event Indicator */}
                            {isCurrent && (
                              <div className="absolute top-3 right-3 px-2 py-1 bg-blue-500 rounded-full">
                                <p className="text-xs text-white font-medium">Now</p>
                              </div>
                            )}
                          </div>
                        </div>
                      ) : (
                        // ===== EXPANDED: PERSONAL EVENT (Icon Card) =====
                        <div className={`relative rounded-[20px] overflow-hidden shadow-md cursor-pointer hover:shadow-xl transition-all bg-gradient-to-br ${event.color} p-5`}>
                          {/* Icon */}
                          <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/30 mb-3">
                            <LifestyleIcon type={event.icon || 'work'} className="text-white text-xl" />
                          </div>
                          
                          {/* Content */}
                          <h3 className="text-white font-bold tracking-tight mb-2">{event.title}</h3>
                          
                          <div className="flex items-center gap-4 text-white/90 text-sm">
                            <div className="flex items-center gap-1.5">
                              <Clock className="w-3.5 h-3.5" />
                              <span>{event.startHour.toString().padStart(2, '0')}:{event.startMinute.toString().padStart(2, '0')} – {event.endHour.toString().padStart(2, '0')}:{event.endMinute.toString().padStart(2, '0')}</span>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-1.5 text-white/80 text-xs mt-1">
                            <MapPin className="w-3 h-3" />
                            <span>{event.location}</span>
                          </div>

                          {/* Current Event Indicator */}
                          {isCurrent && (
                            <div className="absolute top-3 right-3 px-2 py-1 bg-white/30 backdrop-blur-sm rounded-full border border-white/40">
                              <p className="text-xs text-white font-medium">Now</p>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* ===== NOW LINE (horizontal durch Event) ===== */}
                  {isCurrent && !isCompact && (
                    <div className="absolute left-0 right-0 h-[2px] bg-blue-500 shadow-sm z-20" 
                         style={{ 
                           top: '50%',
                           transform: 'translateY(-50%)'
                         }}>
                      <div className="absolute -left-1 -top-1.5 w-3 h-3 bg-blue-500 rounded-full"></div>
                      <div className="absolute -right-1 -top-1.5 w-3 h-3 bg-blue-500 rounded-full"></div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

export function CalendarView() {
  const [viewMode, setViewMode] = useState<ViewMode>('week');
  const [showAddSheet, setShowAddSheet] = useState(false);
  const [calendarTheme, setCalendarTheme] = useState<CalendarTheme>('daylight');
  const [showThemeSelector, setShowThemeSelector] = useState(false);
  const [isWeekCompact, setIsWeekCompact] = useState(false); // Toggle for week compact view

  const handleAdd = (item: any) => {
    console.log('Adding to calendar:', item);
  };

  return (
    <div className="min-h-screen bg-white pb-6">
      <header className="sticky top-0 bg-white/80 backdrop-blur-lg z-20 px-6 pt-6 pb-4 border-b border-gray-100">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1>Calendar</h1>
            <p className="text-sm text-gray-500">December 2024</p>
          </div>
          <div className="flex items-center gap-2">
            {/* Week Compact Toggle */}
            {viewMode === 'week' && (
              <button
                onClick={() => setIsWeekCompact(!isWeekCompact)}
                className="p-2 hover:bg-gray-100 rounded-full transition"
                title={isWeekCompact ? 'Expand view' : 'Compact view'}
              >
                {isWeekCompact ? (
                  <svg className="w-5 h-5 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
                  </svg>
                ) : (
                  <svg className="w-5 h-5 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8h16M4 16h16" />
                  </svg>
                )}
              </button>
            )}
            
            {/* Theme Selector Button */}
            {viewMode === 'week' && (
              <button 
                onClick={() => setShowThemeSelector(true)}
                className="p-2 hover:bg-gray-100 rounded-full transition"
              >
                <Palette className="w-5 h-5 text-gray-700" />
              </button>
            )}
            <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-full text-sm hover:bg-gray-200 transition">
              Today
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-gray-100 p-1 rounded-full">
          <button
            onClick={() => setViewMode('day')}
            className={`flex-1 px-4 py-2 rounded-full text-sm transition-all ${
              viewMode === 'day' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-600'
            }`}
          >
            Day
          </button>
          <button
            onClick={() => setViewMode('week')}
            className={`flex-1 px-4 py-2 rounded-full text-sm transition-all ${
              viewMode === 'week' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-600'
            }`}
          >
            Week
          </button>
          <button
            onClick={() => setViewMode('month')}
            className={`flex-1 px-4 py-2 rounded-full text-sm transition-all ${
              viewMode === 'month' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-600'
            }`}
          >
            Month
          </button>
        </div>
      </header>

      <div className="py-6">
        {viewMode === 'day' && <DayView />}
        {viewMode === 'week' && <WeekCanvasEditorial theme={calendarTheme} isCompact={isWeekCompact} />}
        {viewMode === 'month' && <MonthCanvasEditorial theme={calendarTheme} />}
      </div>

      {/* Theme Selector Bottom Sheet */}
      {showThemeSelector && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 backdrop-blur-sm"
          onClick={() => setShowThemeSelector(false)}
        >
          <div
            className="bg-white rounded-t-[24px] w-full max-w-md shadow-2xl animate-slide-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 space-y-4">
              <div>
                <h2>Calendar Theme</h2>
                <p className="text-sm text-gray-500 mt-1">Choose your vibe</p>
              </div>

              <div className="space-y-3">
                {/* Daylight Theme */}
                <button
                  onClick={() => {
                    setCalendarTheme('daylight');
                    setShowThemeSelector(false);
                  }}
                  className={`w-full p-4 rounded-[16px] border-2 transition-all ${
                    calendarTheme === 'daylight'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 bg-white hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-[12px] bg-gradient-to-br from-blue-50 via-green-50/50 to-gray-50 border border-gray-200 flex-shrink-0"></div>
                    <div className="flex-1 text-left">
                      <h4 className="text-gray-900">Daylight Editorial</h4>
                      <p className="text-sm text-gray-500">Clean & lifestyle</p>
                    </div>
                    {calendarTheme === 'daylight' && (
                      <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                      </div>
                    )}
                  </div>
                </button>

                {/* Neon Theme */}
                <button
                  onClick={() => {
                    setCalendarTheme('neon');
                    setShowThemeSelector(false);
                  }}
                  className={`w-full p-4 rounded-[16px] border-2 transition-all ${
                    calendarTheme === 'neon'
                      ? 'border-purple-500 bg-purple-50'
                      : 'border-gray-200 bg-white hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-[12px] bg-gradient-to-br from-purple-500 to-pink-500 flex-shrink-0"></div>
                    <div className="flex-1 text-left">
                      <h4 className="text-gray-900">Neon Night</h4>
                      <p className="text-sm text-gray-500">Dark & electric</p>
                    </div>
                    {calendarTheme === 'neon' && (
                      <div className="w-5 h-5 bg-purple-500 rounded-full flex items-center justify-center">
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                      </div>
                    )}
                  </div>
                </button>

                {/* Paper Theme */}
                <button
                  onClick={() => {
                    setCalendarTheme('paper');
                    setShowThemeSelector(false);
                  }}
                  className={`w-full p-4 rounded-[16px] border-2 transition-all ${
                    calendarTheme === 'paper'
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 bg-white hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-[12px] bg-gradient-to-br from-orange-400 to-amber-500 flex-shrink-0"></div>
                    <div className="flex-1 text-left">
                      <h4 className="text-gray-900">Warm Paper</h4>
                      <p className="text-sm text-gray-500">Textured & warm</p>
                    </div>
                    {calendarTheme === 'paper' && (
                      <div className="w-5 h-5 bg-orange-500 rounded-full flex items-center justify-center">
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                      </div>
                    )}
                  </div>
                </button>
              </div>

              <button
                onClick={() => setShowThemeSelector(false)}
                className="w-full text-gray-400 text-sm hover:text-gray-600 transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Unified Power Button FAB */}
      <button 
        onClick={() => setShowAddSheet(true)}
        className="fixed bottom-24 right-6 w-14 h-14 btn-power rounded-full shadow-2xl flex items-center justify-center z-20 hover:scale-105 active:scale-95 transition-transform"
      >
        <Sparkles className="w-6 h-6 text-white" />
      </button>

      {/* Add to Calendar Sheet */}
      {showAddSheet && (
        <AddToCalendarSheet
          onClose={() => setShowAddSheet(false)}
          onAdd={handleAdd}
        />
      )}
    </div>
  );
}