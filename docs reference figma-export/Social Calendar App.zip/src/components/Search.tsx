import { Search as SearchIcon, Users, GraduationCap, MapPin } from 'lucide-react';
import { useState } from 'react';
import { PersonCard, PersonCardCompact, type PersonData } from './PersonCard';

const mockPeopleNearby: PersonData[] = [
  {
    id: 'p1',
    name: 'Max Klein',
    initials: 'MK',
    descriptor: 'Active tonight',
    mutualFriends: 3,
    type: 'person',
  },
  {
    id: 'p2',
    name: 'Julia Schmidt',
    initials: 'JS',
    descriptor: '12 events/month',
    mutualFriends: 5,
    type: 'person',
  },
  {
    id: 'p3',
    name: 'Alex Weber',
    initials: 'AW',
    descriptor: 'New to area',
    mutualFriends: 2,
    type: 'person',
  },
  {
    id: 'p4',
    name: 'Lisa Müller',
    initials: 'LM',
    descriptor: 'Sports enthusiast',
    mutualFriends: 1,
    type: 'person',
  },
];

const mockCrews: PersonData[] = [
  {
    id: 'c1',
    name: 'Running Group',
    initials: 'RG',
    descriptor: '12 events/month',
    nextEvent: 'Next: Tue 18:00',
    eventThumbnails: [
      'https://images.unsplash.com/photo-1699959560616-aa17ace76879?w=200',
      'https://images.unsplash.com/photo-1699959560616-aa17ace76879?w=200',
    ],
    type: 'crew',
  },
  {
    id: 'c2',
    name: 'Party Crew',
    initials: 'PC',
    descriptor: '8 events/month',
    nextEvent: 'Next: Fri 20:00',
    eventThumbnails: [
      'https://images.unsplash.com/photo-1759870075384-4e82adc2f679?w=200',
    ],
    type: 'crew',
  },
  {
    id: 'c3',
    name: 'Tennis Club',
    initials: 'TC',
    descriptor: '6 events/month',
    nextEvent: 'Next: Wed 17:00',
    eventThumbnails: [
      'https://images.unsplash.com/photo-1494251202008-582bbc3eac69?w=200',
    ],
    type: 'crew',
  },
];

const mockProfessors: PersonData[] = [
  {
    id: 'prof1',
    name: 'Dr. Sarah Johnson',
    initials: 'SJ',
    descriptor: 'Computer Science',
    nextEvent: 'Office hours: Thu 14:00',
    type: 'professor',
  },
  {
    id: 'prof2',
    name: 'Prof. Michael Brown',
    initials: 'MB',
    descriptor: 'Mathematics',
    nextEvent: 'Guest lecture: Mon 16:00',
    type: 'professor',
  },
];

const mockPlaces: PersonData[] = [
  {
    id: 'place1',
    name: 'Campus Library',
    initials: '📚',
    descriptor: 'Study spots available',
    nextEvent: '15 events this week',
    type: 'place',
  },
  {
    id: 'place2',
    name: 'Central Park',
    initials: '🌳',
    descriptor: 'Popular for sports',
    nextEvent: '8 events this week',
    type: 'place',
  },
];

export function Search() {
  const [searchQuery, setSearchQuery] = useState('');

  const handleFollow = (personId: string) => {
    console.log('Following:', personId);
  };

  return (
    <div className="min-h-screen bg-white pb-6">
      {/* Header */}
      <header className="sticky top-0 bg-white/80 backdrop-blur-lg z-10 px-6 pt-6 pb-4 border-b border-gray-100">
        <h1>Discover</h1>
        <p className="text-sm text-gray-500 mt-1">Find people, crews & places</p>

        {/* Search Bar */}
        <div className="relative mt-4">
          <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search friends, crews, professors, places"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-[20px] bg-gray-50 border-2 border-transparent focus:border-blue-500 focus:bg-white focus:outline-none transition"
          />
        </div>
      </header>

      {/* Content */}
      <div className="space-y-8 py-6">
        {/* People Near You */}
        <div>
          <div className="px-6 mb-4 flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-500" />
            <h2 className="text-lg">People Near You</h2>
          </div>
          <div className="px-6">
            <div className="grid grid-cols-2 gap-4">
              {mockPeopleNearby.map((person) => (
                <PersonCardCompact key={person.id} person={person} onFollow={handleFollow} />
              ))}
            </div>
          </div>
        </div>

        {/* Crews */}
        <div>
          <div className="px-6 mb-4 flex items-center gap-2">
            <Users className="w-5 h-5 text-green-500" />
            <h2 className="text-lg">Crews</h2>
          </div>
          <div className="px-6 space-y-3">
            {mockCrews.map((crew) => (
              <PersonCard
                key={crew.id}
                person={crew}
                onFollow={handleFollow}
              />
            ))}
          </div>
        </div>

        {/* Professors / Hosts */}
        <div>
          <div className="px-6 mb-4 flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-purple-500" />
            <h2 className="text-lg">Professors & Hosts</h2>
          </div>
          <div className="px-6 space-y-3">
            {mockProfessors.map((prof) => (
              <PersonCard
                key={prof.id}
                person={prof}
                onFollow={handleFollow}
              />
            ))}
          </div>
        </div>

        {/* Places */}
        <div>
          <div className="px-6 mb-4 flex items-center gap-2">
            <MapPin className="w-5 h-5 text-orange-500" />
            <h2 className="text-lg">Places</h2>
          </div>
          <div className="px-6 space-y-3">
            {mockPlaces.map((place) => (
              <PersonCard
                key={place.id}
                person={place}
                onFollow={handleFollow}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
