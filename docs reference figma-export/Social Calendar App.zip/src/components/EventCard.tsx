import { Clock, MapPin, Users, Check, Sparkles, Navigation } from 'lucide-react';
import { useState } from 'react';

export type EventCardData = {
  id: string;
  title: string;
  imageUrl: string;
  time: string;
  endTime?: string;
  location: string;
  source: string;
  attendees?: number;
  friendsGoing?: number;
  contextLabel?: string;
  distance?: string; // "12 min walk" or "10 min ride"
  category?: 'university' | 'sports' | 'nightlife' | 'personal';
};

type EventCardProps = {
  event: EventCardData;
  onAdd: (eventId: string) => void;
  onClick?: (event: EventCardData) => void;
  className?: string;
  isAdded?: boolean;
  variant?: 'default' | 'compact'; // compact for Network previews
};

export function EventCard({ event, onAdd, onClick, className = '', isAdded = false, variant = 'default' }: EventCardProps) {
  const [added, setAdded] = useState(isAdded);
  const [isAnimating, setIsAnimating] = useState(false);

  const handleAddClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (added) return;
    
    setIsAnimating(true);
    setAdded(true);
    onAdd(event.id);
    
    setTimeout(() => {
      setIsAnimating(false);
    }, 600);
  };

  const timeRange = event.endTime 
    ? `${event.time} - ${event.endTime}` 
    : event.time;

  if (variant === 'compact') {
    return (
      <div
        onClick={() => onClick?.(event)}
        className={`bg-white rounded-[16px] overflow-hidden shadow-sm hover:shadow-md transition-all cursor-pointer ${className}`}
      >
        <div className="flex gap-3 p-3">
          <div className="w-20 h-20 rounded-[12px] overflow-hidden flex-shrink-0">
            <img
              src={event.imageUrl}
              alt={event.title}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm text-gray-500 mb-1">{event.source}</p>
            <h4 className="text-sm text-gray-900 line-clamp-1 mb-1">{event.title}</h4>
            <div className="flex items-center gap-2 text-xs text-gray-600">
              <Clock className="w-3 h-3" />
              <span>{event.time}</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      onClick={() => onClick?.(event)}
      className={`bg-white rounded-[20px] overflow-hidden shadow-md hover:shadow-lg transition-all cursor-pointer ${
        isAnimating ? 'animate-fly-to-calendar' : ''
      } ${className}`}
    >
      {/* Top Area: Source + Social Proof */}
      <div className="px-4 pt-3 pb-2 flex items-center justify-between">
        <span className="chip-source">{event.source}</span>
        
        {event.friendsGoing ? (
          <div className="chip-social">
            <Users className="w-3 h-3" />
            <span>{event.friendsGoing} friends going</span>
          </div>
        ) : event.attendees ? (
          <div className="chip-social">
            <Users className="w-3 h-3" />
            <span>{event.attendees} going</span>
          </div>
        ) : null}
      </div>

      {/* Middle: Image */}
      <div className="px-4 pb-3">
        <div className="relative aspect-[16/10] rounded-[16px] overflow-hidden">
          <img
            src={event.imageUrl}
            alt={event.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>
          
          {/* Title Overlay */}
          <div className="absolute bottom-0 left-0 right-0 p-4">
            <h3 className="text-white">{event.title}</h3>
          </div>
        </div>
      </div>

      {/* Bottom: Info Strip */}
      <div className="px-4 pb-4 space-y-2">
        <div className="flex items-start justify-between text-sm">
          <div className="flex items-center gap-2 text-gray-700">
            <Clock className="w-4 h-4 text-gray-500" />
            <span>{timeRange}</span>
          </div>
          
          <div className="flex items-center gap-1 text-gray-600">
            <MapPin className="w-4 h-4 text-gray-500" />
            <span className="text-sm">{event.location}</span>
          </div>
        </div>

        {/* Distance + Context */}
        <div className="flex items-center gap-2 text-xs">
          {event.distance && (
            <div className="flex items-center gap-1 text-gray-600">
              <Navigation className="w-3 h-3" />
              <span>{event.distance}</span>
            </div>
          )}
          {event.contextLabel && (
            <div className="chip-context">
              <span>{event.contextLabel}</span>
            </div>
          )}
        </div>

        {/* Power Button */}
        <button
          onClick={handleAddClick}
          disabled={added}
          className={`w-full btn-power ${added ? 'success' : 'animate-pulse-power'}`}
        >
          {added ? (
            <>
              <Check className="w-5 h-5" />
              <span className="font-medium">Added ✓</span>
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5" />
              <span className="font-medium">Add to My Flow</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
}

// Mini version for timeline/calendar
export function EventCardMini({ event, onClick }: { event: EventCardData; onClick?: () => void }) {
  return (
    <div
      onClick={onClick}
      className="bg-white rounded-[12px] overflow-hidden shadow-sm cursor-pointer hover:shadow-md transition-all"
    >
      <div className="relative h-16">
        <img
          src={event.imageUrl}
          alt={event.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
        <div className="absolute bottom-0 left-0 right-0 p-2">
          <p className="text-white text-xs line-clamp-1">{event.title}</p>
        </div>
      </div>
    </div>
  );
}